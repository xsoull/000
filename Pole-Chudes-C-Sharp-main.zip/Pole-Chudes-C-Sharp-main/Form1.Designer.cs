﻿//  Foobar is free software: you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation, either version 3 of the License, or
//  (at your option) any later version.
//
//  Foobar is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with Foobar.  If not, see <http://www.gnu.org/licenses/>.

namespace Pole_Chudes_Beta_1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.играToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выбратьДругуюТемуToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.выбратьДругуюТемуToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.выбратьДругуюТемуToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.выйтиToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.оПрограммеToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnNewGame = new System.Windows.Forms.Button();
            this.lblVybor = new System.Windows.Forms.Label();
            this.btnProg = new System.Windows.Forms.Button();
            this.btnPoc = new System.Windows.Forms.Button();
            this.btnRast = new System.Windows.Forms.Button();
            this.tbPName = new System.Windows.Forms.TextBox();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.btnBaraban = new System.Windows.Forms.Button();
            this.timer3 = new System.Windows.Forms.Timer(this.components);
            this.timer4 = new System.Windows.Forms.Timer(this.components);
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.button3 = new System.Windows.Forms.Button();
            this.button4 = new System.Windows.Forms.Button();
            this.button5 = new System.Windows.Forms.Button();
            this.button6 = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.button10 = new System.Windows.Forms.Button();
            this.button11 = new System.Windows.Forms.Button();
            this.button12 = new System.Windows.Forms.Button();
            this.button13 = new System.Windows.Forms.Button();
            this.button14 = new System.Windows.Forms.Button();
            this.button15 = new System.Windows.Forms.Button();
            this.button16 = new System.Windows.Forms.Button();
            this.button17 = new System.Windows.Forms.Button();
            this.button18 = new System.Windows.Forms.Button();
            this.button19 = new System.Windows.Forms.Button();
            this.button20 = new System.Windows.Forms.Button();
            this.button21 = new System.Windows.Forms.Button();
            this.button22 = new System.Windows.Forms.Button();
            this.button23 = new System.Windows.Forms.Button();
            this.button24 = new System.Windows.Forms.Button();
            this.button25 = new System.Windows.Forms.Button();
            this.button26 = new System.Windows.Forms.Button();
            this.button27 = new System.Windows.Forms.Button();
            this.button28 = new System.Windows.Forms.Button();
            this.button29 = new System.Windows.Forms.Button();
            this.button30 = new System.Windows.Forms.Button();
            this.button31 = new System.Windows.Forms.Button();
            this.button32 = new System.Windows.Forms.Button();
            this.button33 = new System.Windows.Forms.Button();
            this.lblB = new System.Windows.Forms.Label();
            this.lblItak = new System.Windows.Forms.Label();
            this.lblBukva = new System.Windows.Forms.Label();
            this.lblOchki = new System.Windows.Forms.Label();
            this.lblVyvodBar = new System.Windows.Forms.Label();
            this.lblNaBarabane = new System.Windows.Forms.Label();
            this.lblBarabanResult = new System.Windows.Forms.Label();
            this.lblCount = new System.Windows.Forms.Label();
            this.lblTextProg1 = new System.Windows.Forms.Label();
            this.List = new System.Windows.Forms.PictureBox();
            this.pbGProg6 = new System.Windows.Forms.PictureBox();
            this.pbGProg5 = new System.Windows.Forms.PictureBox();
            this.pbGProg4 = new System.Windows.Forms.PictureBox();
            this.pbGProg3 = new System.Windows.Forms.PictureBox();
            this.pbGProg2 = new System.Windows.Forms.PictureBox();
            this.pbGProg1 = new System.Windows.Forms.PictureBox();
            this.lblPlayerName1 = new System.Windows.Forms.Label();
            this.lblErr = new System.Windows.Forms.Label();
            this.lblEnterName = new System.Windows.Forms.Label();
            this.ThemeBack = new System.Windows.Forms.PictureBox();
            this.pbPlayerStatus = new System.Windows.Forms.PictureBox();
            this.MenuBack = new System.Windows.Forms.PictureBox();
            this.GameBack = new System.Windows.Forms.PictureBox();
            this.lblA = new System.Windows.Forms.Label();
            this.lblI = new System.Windows.Forms.Label();
            this.lblS = new System.Windows.Forms.Label();
            this.lblii = new System.Windows.Forms.Label();
            this.lblC = new System.Windows.Forms.Label();
            this.timer5 = new System.Windows.Forms.Timer(this.components);
            this.lblTextProg2 = new System.Windows.Forms.Label();
            this.timer6 = new System.Windows.Forms.Timer(this.components);
            this.lblTextProg3 = new System.Windows.Forms.Label();
            this.lblTextProg4 = new System.Windows.Forms.Label();
            this.timer7 = new System.Windows.Forms.Timer(this.components);
            this.lblSlovoCount = new System.Windows.Forms.Label();
            this.lblOne = new System.Windows.Forms.Label();
            this.lblTwo = new System.Windows.Forms.Label();
            this.lblThree = new System.Windows.Forms.Label();
            this.lblFour = new System.Windows.Forms.Label();
            this.lblFive = new System.Windows.Forms.Label();
            this.lblSix = new System.Windows.Forms.Label();
            this.timer8 = new System.Windows.Forms.Timer(this.components);
            this.btnSrazyProg = new System.Windows.Forms.Button();
            this.tbSrazyProg = new System.Windows.Forms.TextBox();
            this.btnProgClose = new System.Windows.Forms.Button();
            this.btnProgOk = new System.Windows.Forms.Button();
            this.pbGProg7 = new System.Windows.Forms.PictureBox();
            this.timer9 = new System.Windows.Forms.Timer(this.components);
            this.lblTextPoc1 = new System.Windows.Forms.Label();
            this.timer10 = new System.Windows.Forms.Timer(this.components);
            this.btnBaraban2 = new System.Windows.Forms.Button();
            this.button34 = new System.Windows.Forms.Button();
            this.button35 = new System.Windows.Forms.Button();
            this.button36 = new System.Windows.Forms.Button();
            this.button37 = new System.Windows.Forms.Button();
            this.button38 = new System.Windows.Forms.Button();
            this.button39 = new System.Windows.Forms.Button();
            this.button40 = new System.Windows.Forms.Button();
            this.button41 = new System.Windows.Forms.Button();
            this.button42 = new System.Windows.Forms.Button();
            this.button43 = new System.Windows.Forms.Button();
            this.button44 = new System.Windows.Forms.Button();
            this.button45 = new System.Windows.Forms.Button();
            this.button46 = new System.Windows.Forms.Button();
            this.button47 = new System.Windows.Forms.Button();
            this.button48 = new System.Windows.Forms.Button();
            this.button49 = new System.Windows.Forms.Button();
            this.button50 = new System.Windows.Forms.Button();
            this.button51 = new System.Windows.Forms.Button();
            this.button52 = new System.Windows.Forms.Button();
            this.button53 = new System.Windows.Forms.Button();
            this.button54 = new System.Windows.Forms.Button();
            this.button55 = new System.Windows.Forms.Button();
            this.button56 = new System.Windows.Forms.Button();
            this.button57 = new System.Windows.Forms.Button();
            this.button58 = new System.Windows.Forms.Button();
            this.button59 = new System.Windows.Forms.Button();
            this.button60 = new System.Windows.Forms.Button();
            this.button61 = new System.Windows.Forms.Button();
            this.button62 = new System.Windows.Forms.Button();
            this.button63 = new System.Windows.Forms.Button();
            this.button64 = new System.Windows.Forms.Button();
            this.button65 = new System.Windows.Forms.Button();
            this.button66 = new System.Windows.Forms.Button();
            this.timer11 = new System.Windows.Forms.Timer(this.components);
            this.timer12 = new System.Windows.Forms.Timer(this.components);
            this.lblK = new System.Windows.Forms.Label();
            this.lblO = new System.Windows.Forms.Label();
            this.lblN = new System.Windows.Forms.Label();
            this.lblY = new System.Windows.Forms.Label();
            this.lblSH = new System.Windows.Forms.Label();
            this.lblE = new System.Windows.Forms.Label();
            this.lblV = new System.Windows.Forms.Label();
            this.timer13 = new System.Windows.Forms.Timer(this.components);
            this.timer14 = new System.Windows.Forms.Timer(this.components);
            this.timer15 = new System.Windows.Forms.Timer(this.components);
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.timer16 = new System.Windows.Forms.Timer(this.components);
            this.btnSrazyPoc = new System.Windows.Forms.Button();
            this.btnPocOk = new System.Windows.Forms.Button();
            this.tbSrazyPoc = new System.Windows.Forms.TextBox();
            this.btnPocClose = new System.Windows.Forms.Button();
            this.timer17 = new System.Windows.Forms.Timer(this.components);
            this.lblTextRast1 = new System.Windows.Forms.Label();
            this.timer18 = new System.Windows.Forms.Timer(this.components);
            this.btnBaraban3 = new System.Windows.Forms.Button();
            this.timer19 = new System.Windows.Forms.Timer(this.components);
            this.timer20 = new System.Windows.Forms.Timer(this.components);
            this.button67 = new System.Windows.Forms.Button();
            this.button68 = new System.Windows.Forms.Button();
            this.button69 = new System.Windows.Forms.Button();
            this.button70 = new System.Windows.Forms.Button();
            this.button71 = new System.Windows.Forms.Button();
            this.button72 = new System.Windows.Forms.Button();
            this.button73 = new System.Windows.Forms.Button();
            this.button74 = new System.Windows.Forms.Button();
            this.button75 = new System.Windows.Forms.Button();
            this.button76 = new System.Windows.Forms.Button();
            this.button77 = new System.Windows.Forms.Button();
            this.button78 = new System.Windows.Forms.Button();
            this.button79 = new System.Windows.Forms.Button();
            this.button80 = new System.Windows.Forms.Button();
            this.button81 = new System.Windows.Forms.Button();
            this.button82 = new System.Windows.Forms.Button();
            this.button83 = new System.Windows.Forms.Button();
            this.button84 = new System.Windows.Forms.Button();
            this.button85 = new System.Windows.Forms.Button();
            this.button86 = new System.Windows.Forms.Button();
            this.button87 = new System.Windows.Forms.Button();
            this.button88 = new System.Windows.Forms.Button();
            this.button89 = new System.Windows.Forms.Button();
            this.button90 = new System.Windows.Forms.Button();
            this.button91 = new System.Windows.Forms.Button();
            this.button92 = new System.Windows.Forms.Button();
            this.button93 = new System.Windows.Forms.Button();
            this.button94 = new System.Windows.Forms.Button();
            this.button95 = new System.Windows.Forms.Button();
            this.button96 = new System.Windows.Forms.Button();
            this.button97 = new System.Windows.Forms.Button();
            this.button98 = new System.Windows.Forms.Button();
            this.button99 = new System.Windows.Forms.Button();
            this.button100 = new System.Windows.Forms.Button();
            this.button101 = new System.Windows.Forms.Button();
            this.button102 = new System.Windows.Forms.Button();
            this.button103 = new System.Windows.Forms.Button();
            this.button104 = new System.Windows.Forms.Button();
            this.button105 = new System.Windows.Forms.Button();
            this.button106 = new System.Windows.Forms.Button();
            this.button107 = new System.Windows.Forms.Button();
            this.button108 = new System.Windows.Forms.Button();
            this.button109 = new System.Windows.Forms.Button();
            this.button110 = new System.Windows.Forms.Button();
            this.button111 = new System.Windows.Forms.Button();
            this.button112 = new System.Windows.Forms.Button();
            this.button113 = new System.Windows.Forms.Button();
            this.button114 = new System.Windows.Forms.Button();
            this.button115 = new System.Windows.Forms.Button();
            this.button116 = new System.Windows.Forms.Button();
            this.button117 = new System.Windows.Forms.Button();
            this.button118 = new System.Windows.Forms.Button();
            this.button119 = new System.Windows.Forms.Button();
            this.button120 = new System.Windows.Forms.Button();
            this.button121 = new System.Windows.Forms.Button();
            this.button122 = new System.Windows.Forms.Button();
            this.button123 = new System.Windows.Forms.Button();
            this.button124 = new System.Windows.Forms.Button();
            this.button125 = new System.Windows.Forms.Button();
            this.button126 = new System.Windows.Forms.Button();
            this.button127 = new System.Windows.Forms.Button();
            this.button128 = new System.Windows.Forms.Button();
            this.button129 = new System.Windows.Forms.Button();
            this.button130 = new System.Windows.Forms.Button();
            this.button131 = new System.Windows.Forms.Button();
            this.button132 = new System.Windows.Forms.Button();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.timer21 = new System.Windows.Forms.Timer(this.components);
            this.timer22 = new System.Windows.Forms.Timer(this.components);
            this.timer23 = new System.Windows.Forms.Timer(this.components);
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.timer24 = new System.Windows.Forms.Timer(this.components);
            this.btnSrazyRast = new System.Windows.Forms.Button();
            this.btnRastOk = new System.Windows.Forms.Button();
            this.tbSrazyRast = new System.Windows.Forms.TextBox();
            this.btnRastClose = new System.Windows.Forms.Button();
            this.menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.List)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGProg6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGProg5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGProg4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGProg3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGProg2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGProg1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ThemeBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPlayerStatus)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.MenuBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GameBack)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGProg7)).BeginInit();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.играToolStripMenuItem,
            this.оПрограммеToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(640, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // играToolStripMenuItem
            // 
            this.играToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.выбратьДругуюТемуToolStripMenuItem,
            this.выбратьДругуюТемуToolStripMenuItem1,
            this.выбратьДругуюТемуToolStripMenuItem2,
            this.выйтиToolStripMenuItem});
            this.играToolStripMenuItem.Name = "играToolStripMenuItem";
            this.играToolStripMenuItem.Size = new System.Drawing.Size(46, 20);
            this.играToolStripMenuItem.Text = "Игра";
            // 
            // выбратьДругуюТемуToolStripMenuItem
            // 
            this.выбратьДругуюТемуToolStripMenuItem.Name = "выбратьДругуюТемуToolStripMenuItem";
            this.выбратьДругуюТемуToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.выбратьДругуюТемуToolStripMenuItem.Text = "Выбрать другую тему";
            this.выбратьДругуюТемуToolStripMenuItem.Visible = false;
            this.выбратьДругуюТемуToolStripMenuItem.Click += new System.EventHandler(this.выбратьДругуюТемуToolStripMenuItem_Click);
            // 
            // выбратьДругуюТемуToolStripMenuItem1
            // 
            this.выбратьДругуюТемуToolStripMenuItem1.Name = "выбратьДругуюТемуToolStripMenuItem1";
            this.выбратьДругуюТемуToolStripMenuItem1.Size = new System.Drawing.Size(193, 22);
            this.выбратьДругуюТемуToolStripMenuItem1.Text = "Выбрать другую тему";
            this.выбратьДругуюТемуToolStripMenuItem1.Visible = false;
            this.выбратьДругуюТемуToolStripMenuItem1.Click += new System.EventHandler(this.выбратьДругуюТемуToolStripMenuItem1_Click);
            // 
            // выбратьДругуюТемуToolStripMenuItem2
            // 
            this.выбратьДругуюТемуToolStripMenuItem2.Name = "выбратьДругуюТемуToolStripMenuItem2";
            this.выбратьДругуюТемуToolStripMenuItem2.Size = new System.Drawing.Size(193, 22);
            this.выбратьДругуюТемуToolStripMenuItem2.Text = "Выбрать другую тему";
            this.выбратьДругуюТемуToolStripMenuItem2.Visible = false;
            this.выбратьДругуюТемуToolStripMenuItem2.Click += new System.EventHandler(this.выбратьДругуюТемуToolStripMenuItem2_Click);
            // 
            // выйтиToolStripMenuItem
            // 
            this.выйтиToolStripMenuItem.Name = "выйтиToolStripMenuItem";
            this.выйтиToolStripMenuItem.Size = new System.Drawing.Size(193, 22);
            this.выйтиToolStripMenuItem.Text = "Выйти";
            this.выйтиToolStripMenuItem.Click += new System.EventHandler(this.выйтиToolStripMenuItem_Click);
            // 
            // оПрограммеToolStripMenuItem
            // 
            this.оПрограммеToolStripMenuItem.Name = "оПрограммеToolStripMenuItem";
            this.оПрограммеToolStripMenuItem.Size = new System.Drawing.Size(94, 20);
            this.оПрограммеToolStripMenuItem.Text = "О программе";
            this.оПрограммеToolStripMenuItem.Click += new System.EventHandler(this.оПрограммеToolStripMenuItem_Click);
            // 
            // btnNewGame
            // 
            this.btnNewGame.BackColor = System.Drawing.SystemColors.Control;
            this.btnNewGame.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnNewGame.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnNewGame.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.btnNewGame.Location = new System.Drawing.Point(12, 413);
            this.btnNewGame.Name = "btnNewGame";
            this.btnNewGame.Size = new System.Drawing.Size(616, 26);
            this.btnNewGame.TabIndex = 2;
            this.btnNewGame.Text = "Начать новую игру";
            this.btnNewGame.UseVisualStyleBackColor = false;
            this.btnNewGame.Click += new System.EventHandler(this.btnNewGame_Click);
            // 
            // lblVybor
            // 
            this.lblVybor.BackColor = System.Drawing.Color.DarkRed;
            this.lblVybor.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVybor.ForeColor = System.Drawing.Color.Yellow;
            this.lblVybor.Location = new System.Drawing.Point(42, 92);
            this.lblVybor.Name = "lblVybor";
            this.lblVybor.Size = new System.Drawing.Size(316, 23);
            this.lblVybor.TabIndex = 5;
            this.lblVybor.Text = "Выберите тему игры:";
            this.lblVybor.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblVybor.Visible = false;
            // 
            // btnProg
            // 
            this.btnProg.BackColor = System.Drawing.SystemColors.Control;
            this.btnProg.Enabled = false;
            this.btnProg.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnProg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnProg.Location = new System.Drawing.Point(42, 130);
            this.btnProg.Name = "btnProg";
            this.btnProg.Size = new System.Drawing.Size(316, 24);
            this.btnProg.TabIndex = 6;
            this.btnProg.Text = "Программирование";
            this.btnProg.UseVisualStyleBackColor = false;
            this.btnProg.Visible = false;
            this.btnProg.Click += new System.EventHandler(this.btnProg_Click);
            // 
            // btnPoc
            // 
            this.btnPoc.BackColor = System.Drawing.SystemColors.Control;
            this.btnPoc.Enabled = false;
            this.btnPoc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnPoc.Location = new System.Drawing.Point(42, 160);
            this.btnPoc.Name = "btnPoc";
            this.btnPoc.Size = new System.Drawing.Size(316, 24);
            this.btnPoc.TabIndex = 7;
            this.btnPoc.Text = "Классный парень";
            this.btnPoc.UseVisualStyleBackColor = false;
            this.btnPoc.Visible = false;
            this.btnPoc.Click += new System.EventHandler(this.btnPoc_Click);
            // 
            // btnRast
            // 
            this.btnRast.BackColor = System.Drawing.SystemColors.Control;
            this.btnRast.Enabled = false;
            this.btnRast.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRast.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnRast.Location = new System.Drawing.Point(42, 190);
            this.btnRast.Name = "btnRast";
            this.btnRast.Size = new System.Drawing.Size(316, 24);
            this.btnRast.TabIndex = 8;
            this.btnRast.Text = "Ботаника";
            this.btnRast.UseVisualStyleBackColor = false;
            this.btnRast.Visible = false;
            this.btnRast.Click += new System.EventHandler(this.btnRast_Click);
            // 
            // tbPName
            // 
            this.tbPName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbPName.Enabled = false;
            this.tbPName.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbPName.Location = new System.Drawing.Point(214, 244);
            this.tbPName.Name = "tbPName";
            this.tbPName.Size = new System.Drawing.Size(133, 24);
            this.tbPName.TabIndex = 10;
            this.tbPName.Visible = false;
            // 
            // timer1
            // 
            this.timer1.Interval = 1500;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // timer2
            // 
            this.timer2.Interval = 10000;
            this.timer2.Tick += new System.EventHandler(this.timer2_Tick);
            // 
            // btnBaraban
            // 
            this.btnBaraban.BackColor = System.Drawing.SystemColors.Control;
            this.btnBaraban.Enabled = false;
            this.btnBaraban.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBaraban.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnBaraban.Location = new System.Drawing.Point(9, 407);
            this.btnBaraban.Name = "btnBaraban";
            this.btnBaraban.Size = new System.Drawing.Size(153, 26);
            this.btnBaraban.TabIndex = 24;
            this.btnBaraban.Text = "Вращать барабан";
            this.btnBaraban.UseVisualStyleBackColor = false;
            this.btnBaraban.Visible = false;
            this.btnBaraban.Click += new System.EventHandler(this.btnBaraban_Click);
            // 
            // timer3
            // 
            this.timer3.Interval = 1000;
            this.timer3.Tick += new System.EventHandler(this.timer3_Tick);
            // 
            // timer4
            // 
            this.timer4.Interval = 3500;
            this.timer4.Tick += new System.EventHandler(this.timer4_Tick);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Control;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button1.Location = new System.Drawing.Point(9, 254);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(31, 31);
            this.button1.TabIndex = 31;
            this.button1.Text = "А";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Visible = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // button2
            // 
            this.button2.BackColor = System.Drawing.SystemColors.Control;
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button2.Location = new System.Drawing.Point(46, 254);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(31, 31);
            this.button2.TabIndex = 32;
            this.button2.Text = "Б";
            this.button2.UseVisualStyleBackColor = false;
            this.button2.Visible = false;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // button3
            // 
            this.button3.BackColor = System.Drawing.SystemColors.Control;
            this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button3.Location = new System.Drawing.Point(84, 254);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(31, 31);
            this.button3.TabIndex = 33;
            this.button3.Text = "В";
            this.button3.UseVisualStyleBackColor = false;
            this.button3.Visible = false;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button4
            // 
            this.button4.BackColor = System.Drawing.SystemColors.Control;
            this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button4.Location = new System.Drawing.Point(121, 254);
            this.button4.Name = "button4";
            this.button4.Size = new System.Drawing.Size(31, 31);
            this.button4.TabIndex = 34;
            this.button4.Text = "Г";
            this.button4.UseVisualStyleBackColor = false;
            this.button4.Visible = false;
            this.button4.Click += new System.EventHandler(this.button4_Click);
            // 
            // button5
            // 
            this.button5.BackColor = System.Drawing.SystemColors.Control;
            this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button5.Location = new System.Drawing.Point(158, 254);
            this.button5.Name = "button5";
            this.button5.Size = new System.Drawing.Size(31, 31);
            this.button5.TabIndex = 35;
            this.button5.Text = "Д";
            this.button5.UseVisualStyleBackColor = false;
            this.button5.Visible = false;
            this.button5.Click += new System.EventHandler(this.button5_Click);
            // 
            // button6
            // 
            this.button6.BackColor = System.Drawing.SystemColors.Control;
            this.button6.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button6.Location = new System.Drawing.Point(195, 254);
            this.button6.Name = "button6";
            this.button6.Size = new System.Drawing.Size(31, 31);
            this.button6.TabIndex = 36;
            this.button6.Text = "Е";
            this.button6.UseVisualStyleBackColor = false;
            this.button6.Visible = false;
            this.button6.Click += new System.EventHandler(this.button6_Click);
            // 
            // button7
            // 
            this.button7.BackColor = System.Drawing.SystemColors.Control;
            this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button7.Location = new System.Drawing.Point(9, 291);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(31, 31);
            this.button7.TabIndex = 37;
            this.button7.Text = "И";
            this.button7.UseVisualStyleBackColor = false;
            this.button7.Visible = false;
            this.button7.Click += new System.EventHandler(this.button7_Click);
            // 
            // button8
            // 
            this.button8.BackColor = System.Drawing.SystemColors.Control;
            this.button8.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button8.Location = new System.Drawing.Point(46, 291);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(31, 31);
            this.button8.TabIndex = 38;
            this.button8.Text = "Й";
            this.button8.UseVisualStyleBackColor = false;
            this.button8.Visible = false;
            this.button8.Click += new System.EventHandler(this.button8_Click);
            // 
            // button9
            // 
            this.button9.BackColor = System.Drawing.SystemColors.Control;
            this.button9.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button9.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button9.Location = new System.Drawing.Point(83, 291);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(31, 31);
            this.button9.TabIndex = 39;
            this.button9.Text = "К";
            this.button9.UseVisualStyleBackColor = false;
            this.button9.Visible = false;
            this.button9.Click += new System.EventHandler(this.button9_Click);
            // 
            // button10
            // 
            this.button10.BackColor = System.Drawing.SystemColors.Control;
            this.button10.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button10.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button10.Location = new System.Drawing.Point(121, 291);
            this.button10.Name = "button10";
            this.button10.Size = new System.Drawing.Size(31, 31);
            this.button10.TabIndex = 40;
            this.button10.Text = "Л";
            this.button10.UseVisualStyleBackColor = false;
            this.button10.Visible = false;
            this.button10.Click += new System.EventHandler(this.button10_Click);
            // 
            // button11
            // 
            this.button11.BackColor = System.Drawing.SystemColors.Control;
            this.button11.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button11.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button11.Location = new System.Drawing.Point(158, 291);
            this.button11.Name = "button11";
            this.button11.Size = new System.Drawing.Size(31, 31);
            this.button11.TabIndex = 41;
            this.button11.Text = "М";
            this.button11.UseVisualStyleBackColor = false;
            this.button11.Visible = false;
            this.button11.Click += new System.EventHandler(this.button11_Click);
            // 
            // button12
            // 
            this.button12.BackColor = System.Drawing.SystemColors.Control;
            this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button12.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button12.Location = new System.Drawing.Point(195, 291);
            this.button12.Name = "button12";
            this.button12.Size = new System.Drawing.Size(31, 31);
            this.button12.TabIndex = 42;
            this.button12.Text = "Н";
            this.button12.UseVisualStyleBackColor = false;
            this.button12.Visible = false;
            this.button12.Click += new System.EventHandler(this.button12_Click);
            // 
            // button13
            // 
            this.button13.BackColor = System.Drawing.SystemColors.Control;
            this.button13.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button13.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button13.Location = new System.Drawing.Point(9, 328);
            this.button13.Name = "button13";
            this.button13.Size = new System.Drawing.Size(31, 31);
            this.button13.TabIndex = 43;
            this.button13.Text = "С";
            this.button13.UseVisualStyleBackColor = false;
            this.button13.Visible = false;
            this.button13.Click += new System.EventHandler(this.button13_Click);
            // 
            // button14
            // 
            this.button14.BackColor = System.Drawing.SystemColors.Control;
            this.button14.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button14.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button14.Location = new System.Drawing.Point(46, 328);
            this.button14.Name = "button14";
            this.button14.Size = new System.Drawing.Size(31, 31);
            this.button14.TabIndex = 44;
            this.button14.Text = "Т";
            this.button14.UseVisualStyleBackColor = false;
            this.button14.Visible = false;
            this.button14.Click += new System.EventHandler(this.button14_Click);
            // 
            // button15
            // 
            this.button15.BackColor = System.Drawing.SystemColors.Control;
            this.button15.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button15.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button15.Location = new System.Drawing.Point(83, 328);
            this.button15.Name = "button15";
            this.button15.Size = new System.Drawing.Size(31, 31);
            this.button15.TabIndex = 45;
            this.button15.Text = "У";
            this.button15.UseVisualStyleBackColor = false;
            this.button15.Visible = false;
            this.button15.Click += new System.EventHandler(this.button15_Click);
            // 
            // button16
            // 
            this.button16.BackColor = System.Drawing.SystemColors.Control;
            this.button16.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button16.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button16.Location = new System.Drawing.Point(121, 328);
            this.button16.Name = "button16";
            this.button16.Size = new System.Drawing.Size(31, 31);
            this.button16.TabIndex = 46;
            this.button16.Text = "Ф";
            this.button16.UseVisualStyleBackColor = false;
            this.button16.Visible = false;
            this.button16.Click += new System.EventHandler(this.button16_Click);
            // 
            // button17
            // 
            this.button17.BackColor = System.Drawing.SystemColors.Control;
            this.button17.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button17.Location = new System.Drawing.Point(158, 328);
            this.button17.Name = "button17";
            this.button17.Size = new System.Drawing.Size(31, 31);
            this.button17.TabIndex = 47;
            this.button17.Text = "Х";
            this.button17.UseVisualStyleBackColor = false;
            this.button17.Visible = false;
            this.button17.Click += new System.EventHandler(this.button17_Click);
            // 
            // button18
            // 
            this.button18.BackColor = System.Drawing.SystemColors.Control;
            this.button18.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button18.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button18.Location = new System.Drawing.Point(195, 328);
            this.button18.Name = "button18";
            this.button18.Size = new System.Drawing.Size(31, 31);
            this.button18.TabIndex = 48;
            this.button18.Text = "Ц";
            this.button18.UseVisualStyleBackColor = false;
            this.button18.Visible = false;
            this.button18.Click += new System.EventHandler(this.button18_Click);
            // 
            // button19
            // 
            this.button19.BackColor = System.Drawing.SystemColors.Control;
            this.button19.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button19.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button19.Location = new System.Drawing.Point(232, 254);
            this.button19.Name = "button19";
            this.button19.Size = new System.Drawing.Size(31, 31);
            this.button19.TabIndex = 49;
            this.button19.Text = "Ё";
            this.button19.UseVisualStyleBackColor = false;
            this.button19.Visible = false;
            this.button19.Click += new System.EventHandler(this.button19_Click);
            // 
            // button20
            // 
            this.button20.BackColor = System.Drawing.SystemColors.Control;
            this.button20.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button20.Location = new System.Drawing.Point(232, 291);
            this.button20.Name = "button20";
            this.button20.Size = new System.Drawing.Size(31, 31);
            this.button20.TabIndex = 50;
            this.button20.Text = "О";
            this.button20.UseVisualStyleBackColor = false;
            this.button20.Visible = false;
            this.button20.Click += new System.EventHandler(this.button20_Click);
            // 
            // button21
            // 
            this.button21.BackColor = System.Drawing.SystemColors.Control;
            this.button21.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button21.Location = new System.Drawing.Point(232, 328);
            this.button21.Name = "button21";
            this.button21.Size = new System.Drawing.Size(31, 31);
            this.button21.TabIndex = 51;
            this.button21.Text = "Ч";
            this.button21.UseVisualStyleBackColor = false;
            this.button21.Visible = false;
            this.button21.Click += new System.EventHandler(this.button21_Click);
            // 
            // button22
            // 
            this.button22.BackColor = System.Drawing.SystemColors.Control;
            this.button22.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button22.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button22.Location = new System.Drawing.Point(269, 254);
            this.button22.Name = "button22";
            this.button22.Size = new System.Drawing.Size(31, 31);
            this.button22.TabIndex = 52;
            this.button22.Text = "Ж";
            this.button22.UseVisualStyleBackColor = false;
            this.button22.Visible = false;
            this.button22.Click += new System.EventHandler(this.button22_Click);
            // 
            // button23
            // 
            this.button23.BackColor = System.Drawing.SystemColors.Control;
            this.button23.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button23.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button23.Location = new System.Drawing.Point(269, 291);
            this.button23.Name = "button23";
            this.button23.Size = new System.Drawing.Size(31, 31);
            this.button23.TabIndex = 53;
            this.button23.Text = "П";
            this.button23.UseVisualStyleBackColor = false;
            this.button23.Visible = false;
            this.button23.Click += new System.EventHandler(this.button23_Click);
            // 
            // button24
            // 
            this.button24.BackColor = System.Drawing.SystemColors.Control;
            this.button24.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button24.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button24.Location = new System.Drawing.Point(269, 328);
            this.button24.Name = "button24";
            this.button24.Size = new System.Drawing.Size(31, 31);
            this.button24.TabIndex = 54;
            this.button24.Text = "Ш";
            this.button24.UseVisualStyleBackColor = false;
            this.button24.Visible = false;
            this.button24.Click += new System.EventHandler(this.button24_Click);
            // 
            // button25
            // 
            this.button25.BackColor = System.Drawing.SystemColors.Control;
            this.button25.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button25.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button25.Location = new System.Drawing.Point(306, 254);
            this.button25.Name = "button25";
            this.button25.Size = new System.Drawing.Size(31, 31);
            this.button25.TabIndex = 55;
            this.button25.Text = "З";
            this.button25.UseVisualStyleBackColor = false;
            this.button25.Visible = false;
            this.button25.Click += new System.EventHandler(this.button25_Click);
            // 
            // button26
            // 
            this.button26.BackColor = System.Drawing.SystemColors.Control;
            this.button26.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button26.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button26.Location = new System.Drawing.Point(306, 291);
            this.button26.Name = "button26";
            this.button26.Size = new System.Drawing.Size(31, 31);
            this.button26.TabIndex = 56;
            this.button26.Text = "Р";
            this.button26.UseVisualStyleBackColor = false;
            this.button26.Visible = false;
            this.button26.Click += new System.EventHandler(this.button26_Click);
            // 
            // button27
            // 
            this.button27.BackColor = System.Drawing.SystemColors.Control;
            this.button27.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button27.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button27.Location = new System.Drawing.Point(306, 328);
            this.button27.Name = "button27";
            this.button27.Size = new System.Drawing.Size(31, 31);
            this.button27.TabIndex = 57;
            this.button27.Text = "Щ";
            this.button27.UseVisualStyleBackColor = false;
            this.button27.Visible = false;
            this.button27.Click += new System.EventHandler(this.button27_Click);
            // 
            // button28
            // 
            this.button28.BackColor = System.Drawing.SystemColors.Control;
            this.button28.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button28.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button28.Location = new System.Drawing.Point(9, 365);
            this.button28.Name = "button28";
            this.button28.Size = new System.Drawing.Size(31, 31);
            this.button28.TabIndex = 58;
            this.button28.Text = "Ъ";
            this.button28.UseVisualStyleBackColor = false;
            this.button28.Visible = false;
            this.button28.Click += new System.EventHandler(this.button28_Click);
            // 
            // button29
            // 
            this.button29.BackColor = System.Drawing.SystemColors.Control;
            this.button29.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button29.Location = new System.Drawing.Point(46, 365);
            this.button29.Name = "button29";
            this.button29.Size = new System.Drawing.Size(31, 31);
            this.button29.TabIndex = 59;
            this.button29.Text = "Ы";
            this.button29.UseVisualStyleBackColor = false;
            this.button29.Visible = false;
            this.button29.Click += new System.EventHandler(this.button29_Click);
            // 
            // button30
            // 
            this.button30.BackColor = System.Drawing.SystemColors.Control;
            this.button30.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button30.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button30.Location = new System.Drawing.Point(83, 365);
            this.button30.Name = "button30";
            this.button30.Size = new System.Drawing.Size(31, 31);
            this.button30.TabIndex = 60;
            this.button30.Text = "Ь";
            this.button30.UseVisualStyleBackColor = false;
            this.button30.Visible = false;
            this.button30.Click += new System.EventHandler(this.button30_Click);
            // 
            // button31
            // 
            this.button31.BackColor = System.Drawing.SystemColors.Control;
            this.button31.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button31.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button31.Location = new System.Drawing.Point(121, 365);
            this.button31.Name = "button31";
            this.button31.Size = new System.Drawing.Size(31, 31);
            this.button31.TabIndex = 61;
            this.button31.Text = "Э";
            this.button31.UseVisualStyleBackColor = false;
            this.button31.Visible = false;
            this.button31.Click += new System.EventHandler(this.button31_Click);
            // 
            // button32
            // 
            this.button32.BackColor = System.Drawing.SystemColors.Control;
            this.button32.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button32.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button32.Location = new System.Drawing.Point(159, 365);
            this.button32.Name = "button32";
            this.button32.Size = new System.Drawing.Size(31, 31);
            this.button32.TabIndex = 62;
            this.button32.Text = "Ю";
            this.button32.UseVisualStyleBackColor = false;
            this.button32.Visible = false;
            this.button32.Click += new System.EventHandler(this.button32_Click);
            // 
            // button33
            // 
            this.button33.BackColor = System.Drawing.SystemColors.Control;
            this.button33.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button33.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button33.Location = new System.Drawing.Point(195, 365);
            this.button33.Name = "button33";
            this.button33.Size = new System.Drawing.Size(31, 31);
            this.button33.TabIndex = 63;
            this.button33.Text = "Я";
            this.button33.UseVisualStyleBackColor = false;
            this.button33.Visible = false;
            this.button33.Click += new System.EventHandler(this.button33_Click);
            // 
            // lblB
            // 
            this.lblB.BackColor = System.Drawing.Color.White;
            this.lblB.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblB.ForeColor = System.Drawing.Color.White;
            this.lblB.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Block;
            this.lblB.Location = new System.Drawing.Point(18, 176);
            this.lblB.Name = "lblB";
            this.lblB.Size = new System.Drawing.Size(35, 39);
            this.lblB.TabIndex = 64;
            this.lblB.Text = "Б";
            this.lblB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblB.Visible = false;
            // 
            // lblItak
            // 
            this.lblItak.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblItak.ForeColor = System.Drawing.Color.White;
            this.lblItak.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.lblItak.Location = new System.Drawing.Point(430, 253);
            this.lblItak.Name = "lblItak";
            this.lblItak.Size = new System.Drawing.Size(46, 22);
            this.lblItak.TabIndex = 27;
            this.lblItak.Text = "Итак,";
            this.lblItak.Visible = false;
            // 
            // lblBukva
            // 
            this.lblBukva.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblBukva.ForeColor = System.Drawing.Color.White;
            this.lblBukva.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.lblBukva.Location = new System.Drawing.Point(430, 272);
            this.lblBukva.Name = "lblBukva";
            this.lblBukva.Size = new System.Drawing.Size(59, 22);
            this.lblBukva.TabIndex = 30;
            this.lblBukva.Text = "Буква?";
            this.lblBukva.Visible = false;
            // 
            // lblOchki
            // 
            this.lblOchki.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOchki.ForeColor = System.Drawing.Color.White;
            this.lblOchki.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.lblOchki.Location = new System.Drawing.Point(496, 253);
            this.lblOchki.Name = "lblOchki";
            this.lblOchki.Size = new System.Drawing.Size(149, 22);
            this.lblOchki.TabIndex = 29;
            this.lblOchki.Text = "очков на барабане!";
            this.lblOchki.Visible = false;
            // 
            // lblVyvodBar
            // 
            this.lblVyvodBar.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblVyvodBar.ForeColor = System.Drawing.Color.White;
            this.lblVyvodBar.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.lblVyvodBar.Location = new System.Drawing.Point(474, 254);
            this.lblVyvodBar.Name = "lblVyvodBar";
            this.lblVyvodBar.Size = new System.Drawing.Size(24, 21);
            this.lblVyvodBar.TabIndex = 28;
            this.lblVyvodBar.Visible = false;
            // 
            // lblNaBarabane
            // 
            this.lblNaBarabane.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblNaBarabane.ForeColor = System.Drawing.Color.White;
            this.lblNaBarabane.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.lblNaBarabane.Location = new System.Drawing.Point(182, 222);
            this.lblNaBarabane.Name = "lblNaBarabane";
            this.lblNaBarabane.Size = new System.Drawing.Size(60, 23);
            this.lblNaBarabane.TabIndex = 26;
            this.lblNaBarabane.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblNaBarabane.Visible = false;
            // 
            // lblBarabanResult
            // 
            this.lblBarabanResult.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblBarabanResult.ForeColor = System.Drawing.Color.White;
            this.lblBarabanResult.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.lblBarabanResult.Location = new System.Drawing.Point(8, 222);
            this.lblBarabanResult.Name = "lblBarabanResult";
            this.lblBarabanResult.Size = new System.Drawing.Size(174, 23);
            this.lblBarabanResult.TabIndex = 25;
            this.lblBarabanResult.Text = "Результат на барабане:";
            this.lblBarabanResult.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblBarabanResult.Visible = false;
            // 
            // lblCount
            // 
            this.lblCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblCount.ForeColor = System.Drawing.Color.White;
            this.lblCount.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.lblCount.Location = new System.Drawing.Point(22, 84);
            this.lblCount.Name = "lblCount";
            this.lblCount.Size = new System.Drawing.Size(158, 53);
            this.lblCount.TabIndex = 23;
            this.lblCount.Text = "0";
            this.lblCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblCount.Visible = false;
            // 
            // lblTextProg1
            // 
            this.lblTextProg1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTextProg1.ForeColor = System.Drawing.Color.White;
            this.lblTextProg1.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.lblTextProg1.Location = new System.Drawing.Point(433, 253);
            this.lblTextProg1.Name = "lblTextProg1";
            this.lblTextProg1.Size = new System.Drawing.Size(203, 155);
            this.lblTextProg1.TabIndex = 22;
            this.lblTextProg1.Text = "В эфире Капитал-шоу Поле чудес! Итак, вопрос. В 1975 году Билл Гейтс и Пол Аллен " +
    "разработали интерпретатор языка для любительского компьютера Альтаир-8800. Как э" +
    "тот язык назывался?";
            this.lblTextProg1.Visible = false;
            // 
            // List
            // 
            this.List.Image = global::Pole_Chudes_Beta_1.Properties.Resources.List;
            this.List.Location = new System.Drawing.Point(428, 24);
            this.List.Name = "List";
            this.List.Size = new System.Drawing.Size(212, 224);
            this.List.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.List.TabIndex = 21;
            this.List.TabStop = false;
            this.List.Visible = false;
            // 
            // pbGProg6
            // 
            this.pbGProg6.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Pole;
            this.pbGProg6.Location = new System.Drawing.Point(289, 173);
            this.pbGProg6.Name = "pbGProg6";
            this.pbGProg6.Size = new System.Drawing.Size(50, 47);
            this.pbGProg6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbGProg6.TabIndex = 20;
            this.pbGProg6.TabStop = false;
            this.pbGProg6.Visible = false;
            // 
            // pbGProg5
            // 
            this.pbGProg5.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Pole;
            this.pbGProg5.Location = new System.Drawing.Point(233, 173);
            this.pbGProg5.Name = "pbGProg5";
            this.pbGProg5.Size = new System.Drawing.Size(50, 47);
            this.pbGProg5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbGProg5.TabIndex = 19;
            this.pbGProg5.TabStop = false;
            this.pbGProg5.Visible = false;
            // 
            // pbGProg4
            // 
            this.pbGProg4.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Pole;
            this.pbGProg4.Location = new System.Drawing.Point(177, 173);
            this.pbGProg4.Name = "pbGProg4";
            this.pbGProg4.Size = new System.Drawing.Size(50, 47);
            this.pbGProg4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbGProg4.TabIndex = 18;
            this.pbGProg4.TabStop = false;
            this.pbGProg4.Visible = false;
            // 
            // pbGProg3
            // 
            this.pbGProg3.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Pole;
            this.pbGProg3.Location = new System.Drawing.Point(121, 173);
            this.pbGProg3.Name = "pbGProg3";
            this.pbGProg3.Size = new System.Drawing.Size(50, 47);
            this.pbGProg3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbGProg3.TabIndex = 17;
            this.pbGProg3.TabStop = false;
            this.pbGProg3.Visible = false;
            // 
            // pbGProg2
            // 
            this.pbGProg2.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Pole;
            this.pbGProg2.Location = new System.Drawing.Point(65, 173);
            this.pbGProg2.Name = "pbGProg2";
            this.pbGProg2.Size = new System.Drawing.Size(50, 47);
            this.pbGProg2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbGProg2.TabIndex = 16;
            this.pbGProg2.TabStop = false;
            this.pbGProg2.Visible = false;
            // 
            // pbGProg1
            // 
            this.pbGProg1.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Pole;
            this.pbGProg1.Location = new System.Drawing.Point(9, 173);
            this.pbGProg1.Name = "pbGProg1";
            this.pbGProg1.Size = new System.Drawing.Size(50, 47);
            this.pbGProg1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbGProg1.TabIndex = 15;
            this.pbGProg1.TabStop = false;
            this.pbGProg1.Visible = false;
            // 
            // lblPlayerName1
            // 
            this.lblPlayerName1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblPlayerName1.ForeColor = System.Drawing.Color.DarkRed;
            this.lblPlayerName1.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.lblPlayerName1.Location = new System.Drawing.Point(24, 40);
            this.lblPlayerName1.Name = "lblPlayerName1";
            this.lblPlayerName1.Size = new System.Drawing.Size(149, 31);
            this.lblPlayerName1.TabIndex = 14;
            this.lblPlayerName1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblPlayerName1.Visible = false;
            // 
            // lblErr
            // 
            this.lblErr.BackColor = System.Drawing.Color.DarkRed;
            this.lblErr.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblErr.ForeColor = System.Drawing.Color.Red;
            this.lblErr.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.lblErr.Location = new System.Drawing.Point(8, 410);
            this.lblErr.Name = "lblErr";
            this.lblErr.Size = new System.Drawing.Size(283, 23);
            this.lblErr.TabIndex = 12;
            this.lblErr.Text = "Ошибка: Вы не ввели своё имя!";
            this.lblErr.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblErr.Visible = false;
            // 
            // lblEnterName
            // 
            this.lblEnterName.BackColor = System.Drawing.Color.DarkRed;
            this.lblEnterName.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblEnterName.ForeColor = System.Drawing.Color.Yellow;
            this.lblEnterName.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.lblEnterName.Location = new System.Drawing.Point(54, 245);
            this.lblEnterName.Name = "lblEnterName";
            this.lblEnterName.Size = new System.Drawing.Size(159, 23);
            this.lblEnterName.TabIndex = 11;
            this.lblEnterName.Text = "Введите своё имя:";
            this.lblEnterName.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.lblEnterName.Visible = false;
            // 
            // ThemeBack
            // 
            this.ThemeBack.BackColor = System.Drawing.Color.DarkRed;
            this.ThemeBack.Location = new System.Drawing.Point(29, 74);
            this.ThemeBack.Name = "ThemeBack";
            this.ThemeBack.Size = new System.Drawing.Size(344, 164);
            this.ThemeBack.TabIndex = 4;
            this.ThemeBack.TabStop = false;
            this.ThemeBack.Visible = false;
            // 
            // pbPlayerStatus
            // 
            this.pbPlayerStatus.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Player;
            this.pbPlayerStatus.Location = new System.Drawing.Point(9, 33);
            this.pbPlayerStatus.Name = "pbPlayerStatus";
            this.pbPlayerStatus.Size = new System.Drawing.Size(177, 117);
            this.pbPlayerStatus.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbPlayerStatus.TabIndex = 13;
            this.pbPlayerStatus.TabStop = false;
            this.pbPlayerStatus.Visible = false;
            // 
            // MenuBack
            // 
            this.MenuBack.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Menu;
            this.MenuBack.Location = new System.Drawing.Point(0, 24);
            this.MenuBack.Name = "MenuBack";
            this.MenuBack.Size = new System.Drawing.Size(640, 417);
            this.MenuBack.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.MenuBack.TabIndex = 0;
            this.MenuBack.TabStop = false;
            // 
            // GameBack
            // 
            this.GameBack.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.GameBack.Location = new System.Drawing.Point(0, 24);
            this.GameBack.Name = "GameBack";
            this.GameBack.Size = new System.Drawing.Size(640, 417);
            this.GameBack.TabIndex = 3;
            this.GameBack.TabStop = false;
            this.GameBack.Visible = false;
            // 
            // lblA
            // 
            this.lblA.BackColor = System.Drawing.Color.White;
            this.lblA.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblA.ForeColor = System.Drawing.Color.White;
            this.lblA.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Block;
            this.lblA.Location = new System.Drawing.Point(74, 176);
            this.lblA.Name = "lblA";
            this.lblA.Size = new System.Drawing.Size(35, 39);
            this.lblA.TabIndex = 65;
            this.lblA.Text = "Е";
            this.lblA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblA.Visible = false;
            // 
            // lblI
            // 
            this.lblI.BackColor = System.Drawing.Color.White;
            this.lblI.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblI.ForeColor = System.Drawing.Color.White;
            this.lblI.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Block;
            this.lblI.Location = new System.Drawing.Point(130, 176);
            this.lblI.Name = "lblI";
            this.lblI.Size = new System.Drawing.Size(35, 39);
            this.lblI.TabIndex = 66;
            this.lblI.Text = "Й";
            this.lblI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblI.Visible = false;
            // 
            // lblS
            // 
            this.lblS.BackColor = System.Drawing.Color.White;
            this.lblS.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblS.ForeColor = System.Drawing.Color.White;
            this.lblS.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Block;
            this.lblS.Location = new System.Drawing.Point(186, 176);
            this.lblS.Name = "lblS";
            this.lblS.Size = new System.Drawing.Size(35, 39);
            this.lblS.TabIndex = 67;
            this.lblS.Text = "С";
            this.lblS.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblS.Visible = false;
            // 
            // lblii
            // 
            this.lblii.BackColor = System.Drawing.Color.White;
            this.lblii.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblii.ForeColor = System.Drawing.Color.White;
            this.lblii.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Block;
            this.lblii.Location = new System.Drawing.Point(242, 176);
            this.lblii.Name = "lblii";
            this.lblii.Size = new System.Drawing.Size(35, 39);
            this.lblii.TabIndex = 68;
            this.lblii.Text = "И";
            this.lblii.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblii.Visible = false;
            // 
            // lblC
            // 
            this.lblC.BackColor = System.Drawing.Color.White;
            this.lblC.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblC.ForeColor = System.Drawing.Color.White;
            this.lblC.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Block;
            this.lblC.Location = new System.Drawing.Point(297, 176);
            this.lblC.Name = "lblC";
            this.lblC.Size = new System.Drawing.Size(35, 39);
            this.lblC.TabIndex = 69;
            this.lblC.Text = "К";
            this.lblC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblC.Visible = false;
            // 
            // timer5
            // 
            this.timer5.Interval = 3500;
            this.timer5.Tick += new System.EventHandler(this.timer5_Tick);
            // 
            // lblTextProg2
            // 
            this.lblTextProg2.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTextProg2.ForeColor = System.Drawing.Color.White;
            this.lblTextProg2.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.lblTextProg2.Location = new System.Drawing.Point(430, 254);
            this.lblTextProg2.Name = "lblTextProg2";
            this.lblTextProg2.Size = new System.Drawing.Size(203, 155);
            this.lblTextProg2.TabIndex = 70;
            this.lblTextProg2.Text = "Совершенно верно! Крутите барабан дальше.";
            this.lblTextProg2.Visible = false;
            // 
            // timer6
            // 
            this.timer6.Interval = 4500;
            this.timer6.Tick += new System.EventHandler(this.timer6_Tick);
            // 
            // lblTextProg3
            // 
            this.lblTextProg3.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTextProg3.ForeColor = System.Drawing.Color.White;
            this.lblTextProg3.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.lblTextProg3.Location = new System.Drawing.Point(430, 254);
            this.lblTextProg3.Name = "lblTextProg3";
            this.lblTextProg3.Size = new System.Drawing.Size(203, 155);
            this.lblTextProg3.TabIndex = 71;
            this.lblTextProg3.Text = "К сожалению, вы выбываете из игры. Приятно было поиграть с вами!";
            this.lblTextProg3.Visible = false;
            // 
            // lblTextProg4
            // 
            this.lblTextProg4.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTextProg4.ForeColor = System.Drawing.Color.White;
            this.lblTextProg4.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.lblTextProg4.Location = new System.Drawing.Point(430, 254);
            this.lblTextProg4.Name = "lblTextProg4";
            this.lblTextProg4.Size = new System.Drawing.Size(203, 155);
            this.lblTextProg4.TabIndex = 72;
            this.lblTextProg4.Text = "Ваши очки аннулированы, но у вас есть ещё один шанс для прокрутки барабана.";
            this.lblTextProg4.Visible = false;
            // 
            // timer7
            // 
            this.timer7.Interval = 5500;
            this.timer7.Tick += new System.EventHandler(this.timer7_Tick);
            // 
            // lblSlovoCount
            // 
            this.lblSlovoCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblSlovoCount.ForeColor = System.Drawing.Color.White;
            this.lblSlovoCount.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.lblSlovoCount.Location = new System.Drawing.Point(361, 29);
            this.lblSlovoCount.Name = "lblSlovoCount";
            this.lblSlovoCount.Size = new System.Drawing.Size(61, 23);
            this.lblSlovoCount.TabIndex = 73;
            this.lblSlovoCount.Text = "0";
            this.lblSlovoCount.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSlovoCount.Visible = false;
            // 
            // lblOne
            // 
            this.lblOne.Enabled = false;
            this.lblOne.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblOne.ForeColor = System.Drawing.Color.White;
            this.lblOne.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.lblOne.Location = new System.Drawing.Point(361, 55);
            this.lblOne.Name = "lblOne";
            this.lblOne.Size = new System.Drawing.Size(61, 23);
            this.lblOne.TabIndex = 74;
            this.lblOne.Text = "1";
            this.lblOne.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblOne.Visible = false;
            // 
            // lblTwo
            // 
            this.lblTwo.Enabled = false;
            this.lblTwo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTwo.ForeColor = System.Drawing.Color.White;
            this.lblTwo.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.lblTwo.Location = new System.Drawing.Point(361, 84);
            this.lblTwo.Name = "lblTwo";
            this.lblTwo.Size = new System.Drawing.Size(61, 23);
            this.lblTwo.TabIndex = 75;
            this.lblTwo.Text = "1";
            this.lblTwo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblTwo.Visible = false;
            // 
            // lblThree
            // 
            this.lblThree.Enabled = false;
            this.lblThree.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblThree.ForeColor = System.Drawing.Color.White;
            this.lblThree.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.lblThree.Location = new System.Drawing.Point(361, 110);
            this.lblThree.Name = "lblThree";
            this.lblThree.Size = new System.Drawing.Size(61, 23);
            this.lblThree.TabIndex = 76;
            this.lblThree.Text = "1";
            this.lblThree.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblThree.Visible = false;
            // 
            // lblFour
            // 
            this.lblFour.Enabled = false;
            this.lblFour.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFour.ForeColor = System.Drawing.Color.White;
            this.lblFour.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.lblFour.Location = new System.Drawing.Point(361, 137);
            this.lblFour.Name = "lblFour";
            this.lblFour.Size = new System.Drawing.Size(61, 23);
            this.lblFour.TabIndex = 77;
            this.lblFour.Text = "1";
            this.lblFour.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblFour.Visible = false;
            // 
            // lblFive
            // 
            this.lblFive.Enabled = false;
            this.lblFive.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblFive.ForeColor = System.Drawing.Color.White;
            this.lblFive.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.lblFive.Location = new System.Drawing.Point(361, 167);
            this.lblFive.Name = "lblFive";
            this.lblFive.Size = new System.Drawing.Size(61, 23);
            this.lblFive.TabIndex = 78;
            this.lblFive.Text = "1";
            this.lblFive.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblFive.Visible = false;
            // 
            // lblSix
            // 
            this.lblSix.Enabled = false;
            this.lblSix.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblSix.ForeColor = System.Drawing.Color.White;
            this.lblSix.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.lblSix.Location = new System.Drawing.Point(361, 197);
            this.lblSix.Name = "lblSix";
            this.lblSix.Size = new System.Drawing.Size(61, 23);
            this.lblSix.TabIndex = 79;
            this.lblSix.Text = "1";
            this.lblSix.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSix.Visible = false;
            // 
            // timer8
            // 
            this.timer8.Interval = 5500;
            this.timer8.Tick += new System.EventHandler(this.timer8_Tick);
            // 
            // btnSrazyProg
            // 
            this.btnSrazyProg.BackColor = System.Drawing.SystemColors.Control;
            this.btnSrazyProg.Enabled = false;
            this.btnSrazyProg.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSrazyProg.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnSrazyProg.Location = new System.Drawing.Point(174, 407);
            this.btnSrazyProg.Name = "btnSrazyProg";
            this.btnSrazyProg.Size = new System.Drawing.Size(173, 26);
            this.btnSrazyProg.TabIndex = 80;
            this.btnSrazyProg.Text = "Ввести слово сразу";
            this.btnSrazyProg.UseVisualStyleBackColor = false;
            this.btnSrazyProg.Visible = false;
            this.btnSrazyProg.Click += new System.EventHandler(this.btnSrazyProg_Click);
            // 
            // tbSrazyProg
            // 
            this.tbSrazyProg.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSrazyProg.Enabled = false;
            this.tbSrazyProg.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbSrazyProg.Location = new System.Drawing.Point(41, 407);
            this.tbSrazyProg.Name = "tbSrazyProg";
            this.tbSrazyProg.Size = new System.Drawing.Size(141, 24);
            this.tbSrazyProg.TabIndex = 81;
            this.tbSrazyProg.Visible = false;
            // 
            // btnProgClose
            // 
            this.btnProgClose.BackColor = System.Drawing.SystemColors.Control;
            this.btnProgClose.Enabled = false;
            this.btnProgClose.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnProgClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnProgClose.Location = new System.Drawing.Point(9, 407);
            this.btnProgClose.Name = "btnProgClose";
            this.btnProgClose.Size = new System.Drawing.Size(26, 24);
            this.btnProgClose.TabIndex = 82;
            this.btnProgClose.Text = "X";
            this.btnProgClose.UseVisualStyleBackColor = false;
            this.btnProgClose.Visible = false;
            this.btnProgClose.Click += new System.EventHandler(this.btnProgClose_Click);
            // 
            // btnProgOk
            // 
            this.btnProgOk.BackColor = System.Drawing.SystemColors.Control;
            this.btnProgOk.Enabled = false;
            this.btnProgOk.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnProgOk.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnProgOk.Location = new System.Drawing.Point(188, 407);
            this.btnProgOk.Name = "btnProgOk";
            this.btnProgOk.Size = new System.Drawing.Size(40, 24);
            this.btnProgOk.TabIndex = 83;
            this.btnProgOk.Text = "ОК";
            this.btnProgOk.UseVisualStyleBackColor = false;
            this.btnProgOk.Visible = false;
            this.btnProgOk.Click += new System.EventHandler(this.btnProgOk_Click);
            // 
            // pbGProg7
            // 
            this.pbGProg7.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Pole;
            this.pbGProg7.Location = new System.Drawing.Point(345, 173);
            this.pbGProg7.Name = "pbGProg7";
            this.pbGProg7.Size = new System.Drawing.Size(50, 47);
            this.pbGProg7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize;
            this.pbGProg7.TabIndex = 84;
            this.pbGProg7.TabStop = false;
            this.pbGProg7.Visible = false;
            // 
            // timer9
            // 
            this.timer9.Interval = 1500;
            this.timer9.Tick += new System.EventHandler(this.timer9_Tick);
            // 
            // lblTextPoc1
            // 
            this.lblTextPoc1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTextPoc1.ForeColor = System.Drawing.Color.White;
            this.lblTextPoc1.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.lblTextPoc1.Location = new System.Drawing.Point(430, 254);
            this.lblTextPoc1.Name = "lblTextPoc1";
            this.lblTextPoc1.Size = new System.Drawing.Size(203, 155);
            this.lblTextPoc1.TabIndex = 85;
            this.lblTextPoc1.Text = "В эфире Капитал-шоу Поле чудес! Итак, тема нашей игры - Классный парень. Предлага" +
    "ю вам вращать барабан!";
            this.lblTextPoc1.Visible = false;
            // 
            // timer10
            // 
            this.timer10.Interval = 6000;
            this.timer10.Tick += new System.EventHandler(this.timer10_Tick);
            // 
            // btnBaraban2
            // 
            this.btnBaraban2.BackColor = System.Drawing.SystemColors.Control;
            this.btnBaraban2.Enabled = false;
            this.btnBaraban2.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBaraban2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnBaraban2.Location = new System.Drawing.Point(9, 407);
            this.btnBaraban2.Name = "btnBaraban2";
            this.btnBaraban2.Size = new System.Drawing.Size(153, 26);
            this.btnBaraban2.TabIndex = 86;
            this.btnBaraban2.Text = "Вращать барабан";
            this.btnBaraban2.UseVisualStyleBackColor = false;
            this.btnBaraban2.Visible = false;
            this.btnBaraban2.Click += new System.EventHandler(this.btnBaraban2_Click);
            // 
            // button34
            // 
            this.button34.BackColor = System.Drawing.SystemColors.Control;
            this.button34.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button34.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button34.Location = new System.Drawing.Point(195, 365);
            this.button34.Name = "button34";
            this.button34.Size = new System.Drawing.Size(31, 31);
            this.button34.TabIndex = 119;
            this.button34.Text = "Я";
            this.button34.UseVisualStyleBackColor = false;
            this.button34.Visible = false;
            this.button34.Click += new System.EventHandler(this.button34_Click);
            // 
            // button35
            // 
            this.button35.BackColor = System.Drawing.SystemColors.Control;
            this.button35.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button35.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button35.Location = new System.Drawing.Point(159, 365);
            this.button35.Name = "button35";
            this.button35.Size = new System.Drawing.Size(31, 31);
            this.button35.TabIndex = 118;
            this.button35.Text = "Ю";
            this.button35.UseVisualStyleBackColor = false;
            this.button35.Visible = false;
            this.button35.Click += new System.EventHandler(this.button35_Click);
            // 
            // button36
            // 
            this.button36.BackColor = System.Drawing.SystemColors.Control;
            this.button36.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button36.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button36.Location = new System.Drawing.Point(121, 365);
            this.button36.Name = "button36";
            this.button36.Size = new System.Drawing.Size(31, 31);
            this.button36.TabIndex = 117;
            this.button36.Text = "Э";
            this.button36.UseVisualStyleBackColor = false;
            this.button36.Visible = false;
            this.button36.Click += new System.EventHandler(this.button36_Click);
            // 
            // button37
            // 
            this.button37.BackColor = System.Drawing.SystemColors.Control;
            this.button37.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button37.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button37.Location = new System.Drawing.Point(83, 365);
            this.button37.Name = "button37";
            this.button37.Size = new System.Drawing.Size(31, 31);
            this.button37.TabIndex = 116;
            this.button37.Text = "Ь";
            this.button37.UseVisualStyleBackColor = false;
            this.button37.Visible = false;
            this.button37.Click += new System.EventHandler(this.button37_Click);
            // 
            // button38
            // 
            this.button38.BackColor = System.Drawing.SystemColors.Control;
            this.button38.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button38.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button38.Location = new System.Drawing.Point(46, 365);
            this.button38.Name = "button38";
            this.button38.Size = new System.Drawing.Size(31, 31);
            this.button38.TabIndex = 115;
            this.button38.Text = "Ы";
            this.button38.UseVisualStyleBackColor = false;
            this.button38.Visible = false;
            this.button38.Click += new System.EventHandler(this.button38_Click);
            // 
            // button39
            // 
            this.button39.BackColor = System.Drawing.SystemColors.Control;
            this.button39.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button39.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button39.Location = new System.Drawing.Point(9, 365);
            this.button39.Name = "button39";
            this.button39.Size = new System.Drawing.Size(31, 31);
            this.button39.TabIndex = 114;
            this.button39.Text = "Ъ";
            this.button39.UseVisualStyleBackColor = false;
            this.button39.Visible = false;
            this.button39.Click += new System.EventHandler(this.button39_Click);
            // 
            // button40
            // 
            this.button40.BackColor = System.Drawing.SystemColors.Control;
            this.button40.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button40.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button40.Location = new System.Drawing.Point(306, 328);
            this.button40.Name = "button40";
            this.button40.Size = new System.Drawing.Size(31, 31);
            this.button40.TabIndex = 113;
            this.button40.Text = "Щ";
            this.button40.UseVisualStyleBackColor = false;
            this.button40.Visible = false;
            this.button40.Click += new System.EventHandler(this.button40_Click);
            // 
            // button41
            // 
            this.button41.BackColor = System.Drawing.SystemColors.Control;
            this.button41.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button41.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button41.Location = new System.Drawing.Point(306, 291);
            this.button41.Name = "button41";
            this.button41.Size = new System.Drawing.Size(31, 31);
            this.button41.TabIndex = 112;
            this.button41.Text = "Р";
            this.button41.UseVisualStyleBackColor = false;
            this.button41.Visible = false;
            this.button41.Click += new System.EventHandler(this.button41_Click);
            // 
            // button42
            // 
            this.button42.BackColor = System.Drawing.SystemColors.Control;
            this.button42.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button42.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button42.Location = new System.Drawing.Point(306, 254);
            this.button42.Name = "button42";
            this.button42.Size = new System.Drawing.Size(31, 31);
            this.button42.TabIndex = 111;
            this.button42.Text = "З";
            this.button42.UseVisualStyleBackColor = false;
            this.button42.Visible = false;
            this.button42.Click += new System.EventHandler(this.button42_Click);
            // 
            // button43
            // 
            this.button43.BackColor = System.Drawing.SystemColors.Control;
            this.button43.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button43.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button43.Location = new System.Drawing.Point(269, 328);
            this.button43.Name = "button43";
            this.button43.Size = new System.Drawing.Size(31, 31);
            this.button43.TabIndex = 110;
            this.button43.Text = "Ш";
            this.button43.UseVisualStyleBackColor = false;
            this.button43.Visible = false;
            this.button43.Click += new System.EventHandler(this.button43_Click);
            // 
            // button44
            // 
            this.button44.BackColor = System.Drawing.SystemColors.Control;
            this.button44.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button44.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button44.Location = new System.Drawing.Point(269, 291);
            this.button44.Name = "button44";
            this.button44.Size = new System.Drawing.Size(31, 31);
            this.button44.TabIndex = 109;
            this.button44.Text = "П";
            this.button44.UseVisualStyleBackColor = false;
            this.button44.Visible = false;
            this.button44.Click += new System.EventHandler(this.button44_Click);
            // 
            // button45
            // 
            this.button45.BackColor = System.Drawing.SystemColors.Control;
            this.button45.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button45.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button45.Location = new System.Drawing.Point(269, 254);
            this.button45.Name = "button45";
            this.button45.Size = new System.Drawing.Size(31, 31);
            this.button45.TabIndex = 108;
            this.button45.Text = "Ж";
            this.button45.UseVisualStyleBackColor = false;
            this.button45.Visible = false;
            this.button45.Click += new System.EventHandler(this.button45_Click);
            // 
            // button46
            // 
            this.button46.BackColor = System.Drawing.SystemColors.Control;
            this.button46.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button46.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button46.Location = new System.Drawing.Point(232, 328);
            this.button46.Name = "button46";
            this.button46.Size = new System.Drawing.Size(31, 31);
            this.button46.TabIndex = 107;
            this.button46.Text = "Ч";
            this.button46.UseVisualStyleBackColor = false;
            this.button46.Visible = false;
            this.button46.Click += new System.EventHandler(this.button46_Click);
            // 
            // button47
            // 
            this.button47.BackColor = System.Drawing.SystemColors.Control;
            this.button47.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button47.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button47.Location = new System.Drawing.Point(232, 291);
            this.button47.Name = "button47";
            this.button47.Size = new System.Drawing.Size(31, 31);
            this.button47.TabIndex = 106;
            this.button47.Text = "О";
            this.button47.UseVisualStyleBackColor = false;
            this.button47.Visible = false;
            this.button47.Click += new System.EventHandler(this.button47_Click);
            // 
            // button48
            // 
            this.button48.BackColor = System.Drawing.SystemColors.Control;
            this.button48.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button48.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button48.Location = new System.Drawing.Point(232, 254);
            this.button48.Name = "button48";
            this.button48.Size = new System.Drawing.Size(31, 31);
            this.button48.TabIndex = 105;
            this.button48.Text = "Ё";
            this.button48.UseVisualStyleBackColor = false;
            this.button48.Visible = false;
            this.button48.Click += new System.EventHandler(this.button48_Click);
            // 
            // button49
            // 
            this.button49.BackColor = System.Drawing.SystemColors.Control;
            this.button49.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button49.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button49.Location = new System.Drawing.Point(195, 328);
            this.button49.Name = "button49";
            this.button49.Size = new System.Drawing.Size(31, 31);
            this.button49.TabIndex = 104;
            this.button49.Text = "Ц";
            this.button49.UseVisualStyleBackColor = false;
            this.button49.Visible = false;
            this.button49.Click += new System.EventHandler(this.button49_Click);
            // 
            // button50
            // 
            this.button50.BackColor = System.Drawing.SystemColors.Control;
            this.button50.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button50.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button50.Location = new System.Drawing.Point(158, 328);
            this.button50.Name = "button50";
            this.button50.Size = new System.Drawing.Size(31, 31);
            this.button50.TabIndex = 103;
            this.button50.Text = "Х";
            this.button50.UseVisualStyleBackColor = false;
            this.button50.Visible = false;
            this.button50.Click += new System.EventHandler(this.button50_Click);
            // 
            // button51
            // 
            this.button51.BackColor = System.Drawing.SystemColors.Control;
            this.button51.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button51.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button51.Location = new System.Drawing.Point(121, 328);
            this.button51.Name = "button51";
            this.button51.Size = new System.Drawing.Size(31, 31);
            this.button51.TabIndex = 102;
            this.button51.Text = "Ф";
            this.button51.UseVisualStyleBackColor = false;
            this.button51.Visible = false;
            this.button51.Click += new System.EventHandler(this.button51_Click);
            // 
            // button52
            // 
            this.button52.BackColor = System.Drawing.SystemColors.Control;
            this.button52.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button52.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button52.Location = new System.Drawing.Point(83, 328);
            this.button52.Name = "button52";
            this.button52.Size = new System.Drawing.Size(31, 31);
            this.button52.TabIndex = 101;
            this.button52.Text = "У";
            this.button52.UseVisualStyleBackColor = false;
            this.button52.Visible = false;
            this.button52.Click += new System.EventHandler(this.button52_Click);
            // 
            // button53
            // 
            this.button53.BackColor = System.Drawing.SystemColors.Control;
            this.button53.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button53.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button53.Location = new System.Drawing.Point(46, 328);
            this.button53.Name = "button53";
            this.button53.Size = new System.Drawing.Size(31, 31);
            this.button53.TabIndex = 100;
            this.button53.Text = "Т";
            this.button53.UseVisualStyleBackColor = false;
            this.button53.Visible = false;
            this.button53.Click += new System.EventHandler(this.button53_Click);
            // 
            // button54
            // 
            this.button54.BackColor = System.Drawing.SystemColors.Control;
            this.button54.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button54.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button54.Location = new System.Drawing.Point(9, 328);
            this.button54.Name = "button54";
            this.button54.Size = new System.Drawing.Size(31, 31);
            this.button54.TabIndex = 99;
            this.button54.Text = "С";
            this.button54.UseVisualStyleBackColor = false;
            this.button54.Visible = false;
            this.button54.Click += new System.EventHandler(this.button54_Click);
            // 
            // button55
            // 
            this.button55.BackColor = System.Drawing.SystemColors.Control;
            this.button55.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button55.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button55.Location = new System.Drawing.Point(195, 291);
            this.button55.Name = "button55";
            this.button55.Size = new System.Drawing.Size(31, 31);
            this.button55.TabIndex = 98;
            this.button55.Text = "Н";
            this.button55.UseVisualStyleBackColor = false;
            this.button55.Visible = false;
            this.button55.Click += new System.EventHandler(this.button55_Click);
            // 
            // button56
            // 
            this.button56.BackColor = System.Drawing.SystemColors.Control;
            this.button56.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button56.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button56.Location = new System.Drawing.Point(158, 291);
            this.button56.Name = "button56";
            this.button56.Size = new System.Drawing.Size(31, 31);
            this.button56.TabIndex = 97;
            this.button56.Text = "М";
            this.button56.UseVisualStyleBackColor = false;
            this.button56.Visible = false;
            this.button56.Click += new System.EventHandler(this.button56_Click);
            // 
            // button57
            // 
            this.button57.BackColor = System.Drawing.SystemColors.Control;
            this.button57.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button57.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button57.Location = new System.Drawing.Point(121, 291);
            this.button57.Name = "button57";
            this.button57.Size = new System.Drawing.Size(31, 31);
            this.button57.TabIndex = 96;
            this.button57.Text = "Л";
            this.button57.UseVisualStyleBackColor = false;
            this.button57.Visible = false;
            this.button57.Click += new System.EventHandler(this.button57_Click);
            // 
            // button58
            // 
            this.button58.BackColor = System.Drawing.SystemColors.Control;
            this.button58.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button58.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button58.Location = new System.Drawing.Point(83, 291);
            this.button58.Name = "button58";
            this.button58.Size = new System.Drawing.Size(31, 31);
            this.button58.TabIndex = 95;
            this.button58.Text = "К";
            this.button58.UseVisualStyleBackColor = false;
            this.button58.Visible = false;
            this.button58.Click += new System.EventHandler(this.button58_Click);
            // 
            // button59
            // 
            this.button59.BackColor = System.Drawing.SystemColors.Control;
            this.button59.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button59.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button59.Location = new System.Drawing.Point(46, 291);
            this.button59.Name = "button59";
            this.button59.Size = new System.Drawing.Size(31, 31);
            this.button59.TabIndex = 94;
            this.button59.Text = "Й";
            this.button59.UseVisualStyleBackColor = false;
            this.button59.Visible = false;
            this.button59.Click += new System.EventHandler(this.button59_Click);
            // 
            // button60
            // 
            this.button60.BackColor = System.Drawing.SystemColors.Control;
            this.button60.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button60.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button60.Location = new System.Drawing.Point(9, 291);
            this.button60.Name = "button60";
            this.button60.Size = new System.Drawing.Size(31, 31);
            this.button60.TabIndex = 93;
            this.button60.Text = "И";
            this.button60.UseVisualStyleBackColor = false;
            this.button60.Visible = false;
            this.button60.Click += new System.EventHandler(this.button60_Click);
            // 
            // button61
            // 
            this.button61.BackColor = System.Drawing.SystemColors.Control;
            this.button61.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button61.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button61.Location = new System.Drawing.Point(195, 254);
            this.button61.Name = "button61";
            this.button61.Size = new System.Drawing.Size(31, 31);
            this.button61.TabIndex = 92;
            this.button61.Text = "Е";
            this.button61.UseVisualStyleBackColor = false;
            this.button61.Visible = false;
            this.button61.Click += new System.EventHandler(this.button61_Click);
            // 
            // button62
            // 
            this.button62.BackColor = System.Drawing.SystemColors.Control;
            this.button62.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button62.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button62.Location = new System.Drawing.Point(158, 254);
            this.button62.Name = "button62";
            this.button62.Size = new System.Drawing.Size(31, 31);
            this.button62.TabIndex = 91;
            this.button62.Text = "Д";
            this.button62.UseVisualStyleBackColor = false;
            this.button62.Visible = false;
            this.button62.Click += new System.EventHandler(this.button62_Click);
            // 
            // button63
            // 
            this.button63.BackColor = System.Drawing.SystemColors.Control;
            this.button63.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button63.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button63.Location = new System.Drawing.Point(121, 254);
            this.button63.Name = "button63";
            this.button63.Size = new System.Drawing.Size(31, 31);
            this.button63.TabIndex = 90;
            this.button63.Text = "Г";
            this.button63.UseVisualStyleBackColor = false;
            this.button63.Visible = false;
            this.button63.Click += new System.EventHandler(this.button63_Click);
            // 
            // button64
            // 
            this.button64.BackColor = System.Drawing.SystemColors.Control;
            this.button64.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button64.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button64.Location = new System.Drawing.Point(84, 254);
            this.button64.Name = "button64";
            this.button64.Size = new System.Drawing.Size(31, 31);
            this.button64.TabIndex = 89;
            this.button64.Text = "В";
            this.button64.UseVisualStyleBackColor = false;
            this.button64.Visible = false;
            this.button64.Click += new System.EventHandler(this.button64_Click);
            // 
            // button65
            // 
            this.button65.BackColor = System.Drawing.SystemColors.Control;
            this.button65.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button65.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button65.Location = new System.Drawing.Point(46, 254);
            this.button65.Name = "button65";
            this.button65.Size = new System.Drawing.Size(31, 31);
            this.button65.TabIndex = 88;
            this.button65.Text = "Б";
            this.button65.UseVisualStyleBackColor = false;
            this.button65.Visible = false;
            this.button65.Click += new System.EventHandler(this.button65_Click);
            // 
            // button66
            // 
            this.button66.BackColor = System.Drawing.SystemColors.Control;
            this.button66.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button66.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button66.Location = new System.Drawing.Point(9, 254);
            this.button66.Name = "button66";
            this.button66.Size = new System.Drawing.Size(31, 31);
            this.button66.TabIndex = 87;
            this.button66.Text = "А";
            this.button66.UseVisualStyleBackColor = false;
            this.button66.Visible = false;
            this.button66.Click += new System.EventHandler(this.button66_Click);
            // 
            // timer11
            // 
            this.timer11.Interval = 1000;
            this.timer11.Tick += new System.EventHandler(this.timer11_Tick);
            // 
            // timer12
            // 
            this.timer12.Interval = 3500;
            this.timer12.Tick += new System.EventHandler(this.timer12_Tick);
            // 
            // lblK
            // 
            this.lblK.BackColor = System.Drawing.Color.White;
            this.lblK.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblK.ForeColor = System.Drawing.Color.White;
            this.lblK.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Block;
            this.lblK.Location = new System.Drawing.Point(18, 176);
            this.lblK.Name = "lblK";
            this.lblK.Size = new System.Drawing.Size(35, 39);
            this.lblK.TabIndex = 120;
            this.lblK.Text = "К";
            this.lblK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblK.Visible = false;
            // 
            // lblO
            // 
            this.lblO.BackColor = System.Drawing.Color.White;
            this.lblO.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblO.ForeColor = System.Drawing.Color.White;
            this.lblO.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Block;
            this.lblO.Location = new System.Drawing.Point(74, 176);
            this.lblO.Name = "lblO";
            this.lblO.Size = new System.Drawing.Size(35, 39);
            this.lblO.TabIndex = 121;
            this.lblO.Text = "О";
            this.lblO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblO.Visible = false;
            // 
            // lblN
            // 
            this.lblN.BackColor = System.Drawing.Color.White;
            this.lblN.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblN.ForeColor = System.Drawing.Color.White;
            this.lblN.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Block;
            this.lblN.Location = new System.Drawing.Point(130, 176);
            this.lblN.Name = "lblN";
            this.lblN.Size = new System.Drawing.Size(35, 39);
            this.lblN.TabIndex = 122;
            this.lblN.Text = "Н";
            this.lblN.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblN.Visible = false;
            // 
            // lblY
            // 
            this.lblY.BackColor = System.Drawing.Color.White;
            this.lblY.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblY.ForeColor = System.Drawing.Color.White;
            this.lblY.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Block;
            this.lblY.Location = new System.Drawing.Point(186, 176);
            this.lblY.Name = "lblY";
            this.lblY.Size = new System.Drawing.Size(35, 39);
            this.lblY.TabIndex = 123;
            this.lblY.Text = "Ы";
            this.lblY.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblY.Visible = false;
            // 
            // lblSH
            // 
            this.lblSH.BackColor = System.Drawing.Color.White;
            this.lblSH.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblSH.ForeColor = System.Drawing.Color.White;
            this.lblSH.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Block;
            this.lblSH.Location = new System.Drawing.Point(242, 176);
            this.lblSH.Name = "lblSH";
            this.lblSH.Size = new System.Drawing.Size(35, 39);
            this.lblSH.TabIndex = 124;
            this.lblSH.Text = "Ш";
            this.lblSH.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblSH.Visible = false;
            // 
            // lblE
            // 
            this.lblE.BackColor = System.Drawing.Color.White;
            this.lblE.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblE.ForeColor = System.Drawing.Color.White;
            this.lblE.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Block;
            this.lblE.Location = new System.Drawing.Point(297, 176);
            this.lblE.Name = "lblE";
            this.lblE.Size = new System.Drawing.Size(35, 39);
            this.lblE.TabIndex = 125;
            this.lblE.Text = "Е";
            this.lblE.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblE.Visible = false;
            // 
            // lblV
            // 
            this.lblV.BackColor = System.Drawing.Color.White;
            this.lblV.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblV.ForeColor = System.Drawing.Color.White;
            this.lblV.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Block;
            this.lblV.Location = new System.Drawing.Point(355, 176);
            this.lblV.Name = "lblV";
            this.lblV.Size = new System.Drawing.Size(35, 39);
            this.lblV.TabIndex = 126;
            this.lblV.Text = "В";
            this.lblV.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.lblV.Visible = false;
            // 
            // timer13
            // 
            this.timer13.Interval = 3500;
            this.timer13.Tick += new System.EventHandler(this.timer13_Tick);
            // 
            // timer14
            // 
            this.timer14.Interval = 4500;
            this.timer14.Tick += new System.EventHandler(this.timer14_Tick);
            // 
            // timer15
            // 
            this.timer15.Interval = 5500;
            this.timer15.Tick += new System.EventHandler(this.timer15_Tick);
            // 
            // label1
            // 
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.label1.Location = new System.Drawing.Point(294, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(61, 23);
            this.label1.TabIndex = 127;
            this.label1.Text = "0";
            this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label1.Visible = false;
            // 
            // label2
            // 
            this.label2.Enabled = false;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.label2.Location = new System.Drawing.Point(294, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 23);
            this.label2.TabIndex = 128;
            this.label2.Text = "1";
            this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label2.Visible = false;
            // 
            // label3
            // 
            this.label3.Enabled = false;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.label3.Location = new System.Drawing.Point(294, 84);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(61, 23);
            this.label3.TabIndex = 129;
            this.label3.Text = "1";
            this.label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label3.Visible = false;
            // 
            // label4
            // 
            this.label4.Enabled = false;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.label4.Location = new System.Drawing.Point(294, 110);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(61, 23);
            this.label4.TabIndex = 130;
            this.label4.Text = "1";
            this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label4.Visible = false;
            // 
            // label5
            // 
            this.label5.Enabled = false;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.label5.Location = new System.Drawing.Point(294, 137);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(61, 23);
            this.label5.TabIndex = 131;
            this.label5.Text = "1";
            this.label5.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label5.Visible = false;
            // 
            // label6
            // 
            this.label6.Enabled = false;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.label6.Location = new System.Drawing.Point(294, 167);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(61, 23);
            this.label6.TabIndex = 132;
            this.label6.Text = "1";
            this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label6.Visible = false;
            // 
            // label7
            // 
            this.label7.Enabled = false;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.label7.Location = new System.Drawing.Point(294, 193);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(61, 23);
            this.label7.TabIndex = 133;
            this.label7.Text = "1";
            this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label7.Visible = false;
            // 
            // label8
            // 
            this.label8.Enabled = false;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.label8.Location = new System.Drawing.Point(294, 218);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(61, 23);
            this.label8.TabIndex = 134;
            this.label8.Text = "1";
            this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label8.Visible = false;
            // 
            // timer16
            // 
            this.timer16.Interval = 5500;
            this.timer16.Tick += new System.EventHandler(this.timer16_Tick);
            // 
            // btnSrazyPoc
            // 
            this.btnSrazyPoc.BackColor = System.Drawing.SystemColors.Control;
            this.btnSrazyPoc.Enabled = false;
            this.btnSrazyPoc.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSrazyPoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnSrazyPoc.Location = new System.Drawing.Point(174, 407);
            this.btnSrazyPoc.Name = "btnSrazyPoc";
            this.btnSrazyPoc.Size = new System.Drawing.Size(173, 26);
            this.btnSrazyPoc.TabIndex = 135;
            this.btnSrazyPoc.Text = "Ввести слово сразу";
            this.btnSrazyPoc.UseVisualStyleBackColor = false;
            this.btnSrazyPoc.Visible = false;
            this.btnSrazyPoc.Click += new System.EventHandler(this.btnSrazyPoc_Click);
            // 
            // btnPocOk
            // 
            this.btnPocOk.BackColor = System.Drawing.SystemColors.Control;
            this.btnPocOk.Enabled = false;
            this.btnPocOk.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPocOk.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnPocOk.Location = new System.Drawing.Point(188, 407);
            this.btnPocOk.Name = "btnPocOk";
            this.btnPocOk.Size = new System.Drawing.Size(40, 24);
            this.btnPocOk.TabIndex = 136;
            this.btnPocOk.Text = "ОК";
            this.btnPocOk.UseVisualStyleBackColor = false;
            this.btnPocOk.Visible = false;
            this.btnPocOk.Click += new System.EventHandler(this.btnPocOk_Click);
            // 
            // tbSrazyPoc
            // 
            this.tbSrazyPoc.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSrazyPoc.Enabled = false;
            this.tbSrazyPoc.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbSrazyPoc.Location = new System.Drawing.Point(41, 407);
            this.tbSrazyPoc.Name = "tbSrazyPoc";
            this.tbSrazyPoc.Size = new System.Drawing.Size(141, 24);
            this.tbSrazyPoc.TabIndex = 137;
            this.tbSrazyPoc.Visible = false;
            // 
            // btnPocClose
            // 
            this.btnPocClose.BackColor = System.Drawing.SystemColors.Control;
            this.btnPocClose.Enabled = false;
            this.btnPocClose.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnPocClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnPocClose.Location = new System.Drawing.Point(9, 407);
            this.btnPocClose.Name = "btnPocClose";
            this.btnPocClose.Size = new System.Drawing.Size(26, 24);
            this.btnPocClose.TabIndex = 138;
            this.btnPocClose.Text = "X";
            this.btnPocClose.UseVisualStyleBackColor = false;
            this.btnPocClose.Visible = false;
            this.btnPocClose.Click += new System.EventHandler(this.btnPocClose_Click);
            // 
            // timer17
            // 
            this.timer17.Interval = 1500;
            this.timer17.Tick += new System.EventHandler(this.timer17_Tick);
            // 
            // lblTextRast1
            // 
            this.lblTextRast1.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.lblTextRast1.ForeColor = System.Drawing.Color.White;
            this.lblTextRast1.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.lblTextRast1.Location = new System.Drawing.Point(430, 254);
            this.lblTextRast1.Name = "lblTextRast1";
            this.lblTextRast1.Size = new System.Drawing.Size(203, 155);
            this.lblTextRast1.TabIndex = 139;
            this.lblTextRast1.Text = "В эфире Капитал-шоу Поле чудес! Итак, загадка. Это растение, как считают целители" +
    ", является источником энергии и жизненных сил. О нём сложено много песен.";
            this.lblTextRast1.Visible = false;
            // 
            // timer18
            // 
            this.timer18.Interval = 10000;
            this.timer18.Tick += new System.EventHandler(this.timer18_Tick);
            // 
            // btnBaraban3
            // 
            this.btnBaraban3.BackColor = System.Drawing.SystemColors.Control;
            this.btnBaraban3.Enabled = false;
            this.btnBaraban3.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnBaraban3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnBaraban3.Location = new System.Drawing.Point(9, 407);
            this.btnBaraban3.Name = "btnBaraban3";
            this.btnBaraban3.Size = new System.Drawing.Size(153, 26);
            this.btnBaraban3.TabIndex = 140;
            this.btnBaraban3.Text = "Вращать барабан";
            this.btnBaraban3.UseVisualStyleBackColor = false;
            this.btnBaraban3.Visible = false;
            this.btnBaraban3.Click += new System.EventHandler(this.btnBaraban3_Click);
            // 
            // timer19
            // 
            this.timer19.Interval = 1000;
            this.timer19.Tick += new System.EventHandler(this.timer19_Tick);
            // 
            // timer20
            // 
            this.timer20.Interval = 3500;
            this.timer20.Tick += new System.EventHandler(this.timer20_Tick);
            // 
            // button67
            // 
            this.button67.BackColor = System.Drawing.SystemColors.Control;
            this.button67.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button67.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button67.Location = new System.Drawing.Point(195, 365);
            this.button67.Name = "button67";
            this.button67.Size = new System.Drawing.Size(31, 31);
            this.button67.TabIndex = 206;
            this.button67.Text = "Я";
            this.button67.UseVisualStyleBackColor = false;
            this.button67.Visible = false;
            this.button67.Click += new System.EventHandler(this.button67_Click);
            // 
            // button68
            // 
            this.button68.BackColor = System.Drawing.SystemColors.Control;
            this.button68.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button68.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button68.Location = new System.Drawing.Point(159, 365);
            this.button68.Name = "button68";
            this.button68.Size = new System.Drawing.Size(31, 31);
            this.button68.TabIndex = 205;
            this.button68.Text = "Ю";
            this.button68.UseVisualStyleBackColor = false;
            this.button68.Visible = false;
            this.button68.Click += new System.EventHandler(this.button68_Click);
            // 
            // button69
            // 
            this.button69.BackColor = System.Drawing.SystemColors.Control;
            this.button69.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button69.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button69.Location = new System.Drawing.Point(121, 365);
            this.button69.Name = "button69";
            this.button69.Size = new System.Drawing.Size(31, 31);
            this.button69.TabIndex = 204;
            this.button69.Text = "Э";
            this.button69.UseVisualStyleBackColor = false;
            this.button69.Visible = false;
            this.button69.Click += new System.EventHandler(this.button69_Click);
            // 
            // button70
            // 
            this.button70.BackColor = System.Drawing.SystemColors.Control;
            this.button70.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button70.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button70.Location = new System.Drawing.Point(83, 365);
            this.button70.Name = "button70";
            this.button70.Size = new System.Drawing.Size(31, 31);
            this.button70.TabIndex = 203;
            this.button70.Text = "Ь";
            this.button70.UseVisualStyleBackColor = false;
            this.button70.Visible = false;
            this.button70.Click += new System.EventHandler(this.button70_Click);
            // 
            // button71
            // 
            this.button71.BackColor = System.Drawing.SystemColors.Control;
            this.button71.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button71.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button71.Location = new System.Drawing.Point(46, 365);
            this.button71.Name = "button71";
            this.button71.Size = new System.Drawing.Size(31, 31);
            this.button71.TabIndex = 202;
            this.button71.Text = "Ы";
            this.button71.UseVisualStyleBackColor = false;
            this.button71.Visible = false;
            this.button71.Click += new System.EventHandler(this.button71_Click);
            // 
            // button72
            // 
            this.button72.BackColor = System.Drawing.SystemColors.Control;
            this.button72.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button72.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button72.Location = new System.Drawing.Point(9, 365);
            this.button72.Name = "button72";
            this.button72.Size = new System.Drawing.Size(31, 31);
            this.button72.TabIndex = 201;
            this.button72.Text = "Ъ";
            this.button72.UseVisualStyleBackColor = false;
            this.button72.Visible = false;
            this.button72.Click += new System.EventHandler(this.button72_Click);
            // 
            // button73
            // 
            this.button73.BackColor = System.Drawing.SystemColors.Control;
            this.button73.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button73.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button73.Location = new System.Drawing.Point(306, 328);
            this.button73.Name = "button73";
            this.button73.Size = new System.Drawing.Size(31, 31);
            this.button73.TabIndex = 200;
            this.button73.Text = "Щ";
            this.button73.UseVisualStyleBackColor = false;
            this.button73.Visible = false;
            this.button73.Click += new System.EventHandler(this.button73_Click);
            // 
            // button74
            // 
            this.button74.BackColor = System.Drawing.SystemColors.Control;
            this.button74.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button74.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button74.Location = new System.Drawing.Point(306, 291);
            this.button74.Name = "button74";
            this.button74.Size = new System.Drawing.Size(31, 31);
            this.button74.TabIndex = 199;
            this.button74.Text = "Р";
            this.button74.UseVisualStyleBackColor = false;
            this.button74.Visible = false;
            this.button74.Click += new System.EventHandler(this.button74_Click);
            // 
            // button75
            // 
            this.button75.BackColor = System.Drawing.SystemColors.Control;
            this.button75.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button75.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button75.Location = new System.Drawing.Point(306, 254);
            this.button75.Name = "button75";
            this.button75.Size = new System.Drawing.Size(31, 31);
            this.button75.TabIndex = 198;
            this.button75.Text = "З";
            this.button75.UseVisualStyleBackColor = false;
            this.button75.Visible = false;
            this.button75.Click += new System.EventHandler(this.button75_Click);
            // 
            // button76
            // 
            this.button76.BackColor = System.Drawing.SystemColors.Control;
            this.button76.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button76.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button76.Location = new System.Drawing.Point(269, 328);
            this.button76.Name = "button76";
            this.button76.Size = new System.Drawing.Size(31, 31);
            this.button76.TabIndex = 197;
            this.button76.Text = "Ш";
            this.button76.UseVisualStyleBackColor = false;
            this.button76.Visible = false;
            this.button76.Click += new System.EventHandler(this.button76_Click);
            // 
            // button77
            // 
            this.button77.BackColor = System.Drawing.SystemColors.Control;
            this.button77.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button77.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button77.Location = new System.Drawing.Point(269, 291);
            this.button77.Name = "button77";
            this.button77.Size = new System.Drawing.Size(31, 31);
            this.button77.TabIndex = 196;
            this.button77.Text = "П";
            this.button77.UseVisualStyleBackColor = false;
            this.button77.Visible = false;
            this.button77.Click += new System.EventHandler(this.button77_Click);
            // 
            // button78
            // 
            this.button78.BackColor = System.Drawing.SystemColors.Control;
            this.button78.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button78.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button78.Location = new System.Drawing.Point(269, 254);
            this.button78.Name = "button78";
            this.button78.Size = new System.Drawing.Size(31, 31);
            this.button78.TabIndex = 195;
            this.button78.Text = "Ж";
            this.button78.UseVisualStyleBackColor = false;
            this.button78.Visible = false;
            this.button78.Click += new System.EventHandler(this.button78_Click);
            // 
            // button79
            // 
            this.button79.BackColor = System.Drawing.SystemColors.Control;
            this.button79.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button79.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button79.Location = new System.Drawing.Point(232, 328);
            this.button79.Name = "button79";
            this.button79.Size = new System.Drawing.Size(31, 31);
            this.button79.TabIndex = 194;
            this.button79.Text = "Ч";
            this.button79.UseVisualStyleBackColor = false;
            this.button79.Visible = false;
            this.button79.Click += new System.EventHandler(this.button79_Click);
            // 
            // button80
            // 
            this.button80.BackColor = System.Drawing.SystemColors.Control;
            this.button80.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button80.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button80.Location = new System.Drawing.Point(232, 291);
            this.button80.Name = "button80";
            this.button80.Size = new System.Drawing.Size(31, 31);
            this.button80.TabIndex = 193;
            this.button80.Text = "О";
            this.button80.UseVisualStyleBackColor = false;
            this.button80.Visible = false;
            this.button80.Click += new System.EventHandler(this.button80_Click);
            // 
            // button81
            // 
            this.button81.BackColor = System.Drawing.SystemColors.Control;
            this.button81.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button81.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button81.Location = new System.Drawing.Point(232, 254);
            this.button81.Name = "button81";
            this.button81.Size = new System.Drawing.Size(31, 31);
            this.button81.TabIndex = 192;
            this.button81.Text = "Ё";
            this.button81.UseVisualStyleBackColor = false;
            this.button81.Visible = false;
            this.button81.Click += new System.EventHandler(this.button81_Click);
            // 
            // button82
            // 
            this.button82.BackColor = System.Drawing.SystemColors.Control;
            this.button82.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button82.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button82.Location = new System.Drawing.Point(195, 328);
            this.button82.Name = "button82";
            this.button82.Size = new System.Drawing.Size(31, 31);
            this.button82.TabIndex = 191;
            this.button82.Text = "Ц";
            this.button82.UseVisualStyleBackColor = false;
            this.button82.Visible = false;
            this.button82.Click += new System.EventHandler(this.button82_Click);
            // 
            // button83
            // 
            this.button83.BackColor = System.Drawing.SystemColors.Control;
            this.button83.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button83.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button83.Location = new System.Drawing.Point(158, 328);
            this.button83.Name = "button83";
            this.button83.Size = new System.Drawing.Size(31, 31);
            this.button83.TabIndex = 190;
            this.button83.Text = "Х";
            this.button83.UseVisualStyleBackColor = false;
            this.button83.Visible = false;
            this.button83.Click += new System.EventHandler(this.button83_Click);
            // 
            // button84
            // 
            this.button84.BackColor = System.Drawing.SystemColors.Control;
            this.button84.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button84.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button84.Location = new System.Drawing.Point(121, 328);
            this.button84.Name = "button84";
            this.button84.Size = new System.Drawing.Size(31, 31);
            this.button84.TabIndex = 189;
            this.button84.Text = "Ф";
            this.button84.UseVisualStyleBackColor = false;
            this.button84.Visible = false;
            this.button84.Click += new System.EventHandler(this.button84_Click);
            // 
            // button85
            // 
            this.button85.BackColor = System.Drawing.SystemColors.Control;
            this.button85.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button85.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button85.Location = new System.Drawing.Point(83, 328);
            this.button85.Name = "button85";
            this.button85.Size = new System.Drawing.Size(31, 31);
            this.button85.TabIndex = 188;
            this.button85.Text = "У";
            this.button85.UseVisualStyleBackColor = false;
            this.button85.Visible = false;
            this.button85.Click += new System.EventHandler(this.button85_Click);
            // 
            // button86
            // 
            this.button86.BackColor = System.Drawing.SystemColors.Control;
            this.button86.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button86.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button86.Location = new System.Drawing.Point(46, 328);
            this.button86.Name = "button86";
            this.button86.Size = new System.Drawing.Size(31, 31);
            this.button86.TabIndex = 187;
            this.button86.Text = "Т";
            this.button86.UseVisualStyleBackColor = false;
            this.button86.Visible = false;
            this.button86.Click += new System.EventHandler(this.button86_Click);
            // 
            // button87
            // 
            this.button87.BackColor = System.Drawing.SystemColors.Control;
            this.button87.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button87.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button87.Location = new System.Drawing.Point(9, 328);
            this.button87.Name = "button87";
            this.button87.Size = new System.Drawing.Size(31, 31);
            this.button87.TabIndex = 186;
            this.button87.Text = "С";
            this.button87.UseVisualStyleBackColor = false;
            this.button87.Visible = false;
            this.button87.Click += new System.EventHandler(this.button87_Click);
            // 
            // button88
            // 
            this.button88.BackColor = System.Drawing.SystemColors.Control;
            this.button88.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button88.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button88.Location = new System.Drawing.Point(195, 291);
            this.button88.Name = "button88";
            this.button88.Size = new System.Drawing.Size(31, 31);
            this.button88.TabIndex = 185;
            this.button88.Text = "Н";
            this.button88.UseVisualStyleBackColor = false;
            this.button88.Visible = false;
            this.button88.Click += new System.EventHandler(this.button88_Click);
            // 
            // button89
            // 
            this.button89.BackColor = System.Drawing.SystemColors.Control;
            this.button89.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button89.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button89.Location = new System.Drawing.Point(158, 291);
            this.button89.Name = "button89";
            this.button89.Size = new System.Drawing.Size(31, 31);
            this.button89.TabIndex = 184;
            this.button89.Text = "М";
            this.button89.UseVisualStyleBackColor = false;
            this.button89.Visible = false;
            this.button89.Click += new System.EventHandler(this.button89_Click);
            // 
            // button90
            // 
            this.button90.BackColor = System.Drawing.SystemColors.Control;
            this.button90.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button90.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button90.Location = new System.Drawing.Point(121, 291);
            this.button90.Name = "button90";
            this.button90.Size = new System.Drawing.Size(31, 31);
            this.button90.TabIndex = 183;
            this.button90.Text = "Л";
            this.button90.UseVisualStyleBackColor = false;
            this.button90.Visible = false;
            this.button90.Click += new System.EventHandler(this.button90_Click);
            // 
            // button91
            // 
            this.button91.BackColor = System.Drawing.SystemColors.Control;
            this.button91.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button91.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button91.Location = new System.Drawing.Point(83, 291);
            this.button91.Name = "button91";
            this.button91.Size = new System.Drawing.Size(31, 31);
            this.button91.TabIndex = 182;
            this.button91.Text = "К";
            this.button91.UseVisualStyleBackColor = false;
            this.button91.Visible = false;
            this.button91.Click += new System.EventHandler(this.button91_Click);
            // 
            // button92
            // 
            this.button92.BackColor = System.Drawing.SystemColors.Control;
            this.button92.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button92.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button92.Location = new System.Drawing.Point(46, 291);
            this.button92.Name = "button92";
            this.button92.Size = new System.Drawing.Size(31, 31);
            this.button92.TabIndex = 181;
            this.button92.Text = "Й";
            this.button92.UseVisualStyleBackColor = false;
            this.button92.Visible = false;
            this.button92.Click += new System.EventHandler(this.button92_Click);
            // 
            // button93
            // 
            this.button93.BackColor = System.Drawing.SystemColors.Control;
            this.button93.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button93.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button93.Location = new System.Drawing.Point(9, 291);
            this.button93.Name = "button93";
            this.button93.Size = new System.Drawing.Size(31, 31);
            this.button93.TabIndex = 180;
            this.button93.Text = "И";
            this.button93.UseVisualStyleBackColor = false;
            this.button93.Visible = false;
            this.button93.Click += new System.EventHandler(this.button93_Click);
            // 
            // button94
            // 
            this.button94.BackColor = System.Drawing.SystemColors.Control;
            this.button94.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button94.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button94.Location = new System.Drawing.Point(195, 254);
            this.button94.Name = "button94";
            this.button94.Size = new System.Drawing.Size(31, 31);
            this.button94.TabIndex = 179;
            this.button94.Text = "Е";
            this.button94.UseVisualStyleBackColor = false;
            this.button94.Visible = false;
            this.button94.Click += new System.EventHandler(this.button94_Click);
            // 
            // button95
            // 
            this.button95.BackColor = System.Drawing.SystemColors.Control;
            this.button95.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button95.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button95.Location = new System.Drawing.Point(158, 254);
            this.button95.Name = "button95";
            this.button95.Size = new System.Drawing.Size(31, 31);
            this.button95.TabIndex = 178;
            this.button95.Text = "Д";
            this.button95.UseVisualStyleBackColor = false;
            this.button95.Visible = false;
            this.button95.Click += new System.EventHandler(this.button95_Click);
            // 
            // button96
            // 
            this.button96.BackColor = System.Drawing.SystemColors.Control;
            this.button96.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button96.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button96.Location = new System.Drawing.Point(121, 254);
            this.button96.Name = "button96";
            this.button96.Size = new System.Drawing.Size(31, 31);
            this.button96.TabIndex = 177;
            this.button96.Text = "Г";
            this.button96.UseVisualStyleBackColor = false;
            this.button96.Visible = false;
            this.button96.Click += new System.EventHandler(this.button96_Click);
            // 
            // button97
            // 
            this.button97.BackColor = System.Drawing.SystemColors.Control;
            this.button97.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button97.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button97.Location = new System.Drawing.Point(84, 254);
            this.button97.Name = "button97";
            this.button97.Size = new System.Drawing.Size(31, 31);
            this.button97.TabIndex = 176;
            this.button97.Text = "В";
            this.button97.UseVisualStyleBackColor = false;
            this.button97.Visible = false;
            this.button97.Click += new System.EventHandler(this.button97_Click);
            // 
            // button98
            // 
            this.button98.BackColor = System.Drawing.SystemColors.Control;
            this.button98.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button98.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button98.Location = new System.Drawing.Point(46, 254);
            this.button98.Name = "button98";
            this.button98.Size = new System.Drawing.Size(31, 31);
            this.button98.TabIndex = 175;
            this.button98.Text = "Б";
            this.button98.UseVisualStyleBackColor = false;
            this.button98.Visible = false;
            this.button98.Click += new System.EventHandler(this.button98_Click);
            // 
            // button99
            // 
            this.button99.BackColor = System.Drawing.SystemColors.Control;
            this.button99.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button99.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button99.Location = new System.Drawing.Point(9, 254);
            this.button99.Name = "button99";
            this.button99.Size = new System.Drawing.Size(31, 31);
            this.button99.TabIndex = 174;
            this.button99.Text = "А";
            this.button99.UseVisualStyleBackColor = false;
            this.button99.Visible = false;
            this.button99.Click += new System.EventHandler(this.button99_Click);
            // 
            // button100
            // 
            this.button100.BackColor = System.Drawing.SystemColors.Control;
            this.button100.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button100.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button100.Location = new System.Drawing.Point(195, 365);
            this.button100.Name = "button100";
            this.button100.Size = new System.Drawing.Size(31, 31);
            this.button100.TabIndex = 173;
            this.button100.Text = "Я";
            this.button100.UseVisualStyleBackColor = false;
            this.button100.Visible = false;
            // 
            // button101
            // 
            this.button101.BackColor = System.Drawing.SystemColors.Control;
            this.button101.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button101.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button101.Location = new System.Drawing.Point(159, 365);
            this.button101.Name = "button101";
            this.button101.Size = new System.Drawing.Size(31, 31);
            this.button101.TabIndex = 172;
            this.button101.Text = "Ю";
            this.button101.UseVisualStyleBackColor = false;
            this.button101.Visible = false;
            // 
            // button102
            // 
            this.button102.BackColor = System.Drawing.SystemColors.Control;
            this.button102.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button102.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button102.Location = new System.Drawing.Point(121, 365);
            this.button102.Name = "button102";
            this.button102.Size = new System.Drawing.Size(31, 31);
            this.button102.TabIndex = 171;
            this.button102.Text = "Э";
            this.button102.UseVisualStyleBackColor = false;
            this.button102.Visible = false;
            // 
            // button103
            // 
            this.button103.BackColor = System.Drawing.SystemColors.Control;
            this.button103.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button103.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button103.Location = new System.Drawing.Point(83, 365);
            this.button103.Name = "button103";
            this.button103.Size = new System.Drawing.Size(31, 31);
            this.button103.TabIndex = 170;
            this.button103.Text = "Ь";
            this.button103.UseVisualStyleBackColor = false;
            this.button103.Visible = false;
            // 
            // button104
            // 
            this.button104.BackColor = System.Drawing.SystemColors.Control;
            this.button104.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button104.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button104.Location = new System.Drawing.Point(46, 365);
            this.button104.Name = "button104";
            this.button104.Size = new System.Drawing.Size(31, 31);
            this.button104.TabIndex = 169;
            this.button104.Text = "Ы";
            this.button104.UseVisualStyleBackColor = false;
            this.button104.Visible = false;
            // 
            // button105
            // 
            this.button105.BackColor = System.Drawing.SystemColors.Control;
            this.button105.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button105.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button105.Location = new System.Drawing.Point(9, 365);
            this.button105.Name = "button105";
            this.button105.Size = new System.Drawing.Size(31, 31);
            this.button105.TabIndex = 168;
            this.button105.Text = "Ъ";
            this.button105.UseVisualStyleBackColor = false;
            this.button105.Visible = false;
            // 
            // button106
            // 
            this.button106.BackColor = System.Drawing.SystemColors.Control;
            this.button106.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button106.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button106.Location = new System.Drawing.Point(306, 328);
            this.button106.Name = "button106";
            this.button106.Size = new System.Drawing.Size(31, 31);
            this.button106.TabIndex = 167;
            this.button106.Text = "Щ";
            this.button106.UseVisualStyleBackColor = false;
            this.button106.Visible = false;
            // 
            // button107
            // 
            this.button107.BackColor = System.Drawing.SystemColors.Control;
            this.button107.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button107.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button107.Location = new System.Drawing.Point(306, 291);
            this.button107.Name = "button107";
            this.button107.Size = new System.Drawing.Size(31, 31);
            this.button107.TabIndex = 166;
            this.button107.Text = "Р";
            this.button107.UseVisualStyleBackColor = false;
            this.button107.Visible = false;
            // 
            // button108
            // 
            this.button108.BackColor = System.Drawing.SystemColors.Control;
            this.button108.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button108.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button108.Location = new System.Drawing.Point(306, 254);
            this.button108.Name = "button108";
            this.button108.Size = new System.Drawing.Size(31, 31);
            this.button108.TabIndex = 165;
            this.button108.Text = "З";
            this.button108.UseVisualStyleBackColor = false;
            this.button108.Visible = false;
            // 
            // button109
            // 
            this.button109.BackColor = System.Drawing.SystemColors.Control;
            this.button109.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button109.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button109.Location = new System.Drawing.Point(269, 328);
            this.button109.Name = "button109";
            this.button109.Size = new System.Drawing.Size(31, 31);
            this.button109.TabIndex = 164;
            this.button109.Text = "Ш";
            this.button109.UseVisualStyleBackColor = false;
            this.button109.Visible = false;
            // 
            // button110
            // 
            this.button110.BackColor = System.Drawing.SystemColors.Control;
            this.button110.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button110.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button110.Location = new System.Drawing.Point(269, 291);
            this.button110.Name = "button110";
            this.button110.Size = new System.Drawing.Size(31, 31);
            this.button110.TabIndex = 163;
            this.button110.Text = "П";
            this.button110.UseVisualStyleBackColor = false;
            this.button110.Visible = false;
            // 
            // button111
            // 
            this.button111.BackColor = System.Drawing.SystemColors.Control;
            this.button111.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button111.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button111.Location = new System.Drawing.Point(269, 254);
            this.button111.Name = "button111";
            this.button111.Size = new System.Drawing.Size(31, 31);
            this.button111.TabIndex = 162;
            this.button111.Text = "Ж";
            this.button111.UseVisualStyleBackColor = false;
            this.button111.Visible = false;
            // 
            // button112
            // 
            this.button112.BackColor = System.Drawing.SystemColors.Control;
            this.button112.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button112.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button112.Location = new System.Drawing.Point(232, 328);
            this.button112.Name = "button112";
            this.button112.Size = new System.Drawing.Size(31, 31);
            this.button112.TabIndex = 161;
            this.button112.Text = "Ч";
            this.button112.UseVisualStyleBackColor = false;
            this.button112.Visible = false;
            // 
            // button113
            // 
            this.button113.BackColor = System.Drawing.SystemColors.Control;
            this.button113.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button113.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button113.Location = new System.Drawing.Point(232, 291);
            this.button113.Name = "button113";
            this.button113.Size = new System.Drawing.Size(31, 31);
            this.button113.TabIndex = 160;
            this.button113.Text = "О";
            this.button113.UseVisualStyleBackColor = false;
            this.button113.Visible = false;
            // 
            // button114
            // 
            this.button114.BackColor = System.Drawing.SystemColors.Control;
            this.button114.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button114.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button114.Location = new System.Drawing.Point(232, 254);
            this.button114.Name = "button114";
            this.button114.Size = new System.Drawing.Size(31, 31);
            this.button114.TabIndex = 159;
            this.button114.Text = "Ё";
            this.button114.UseVisualStyleBackColor = false;
            this.button114.Visible = false;
            // 
            // button115
            // 
            this.button115.BackColor = System.Drawing.SystemColors.Control;
            this.button115.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button115.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button115.Location = new System.Drawing.Point(195, 328);
            this.button115.Name = "button115";
            this.button115.Size = new System.Drawing.Size(31, 31);
            this.button115.TabIndex = 158;
            this.button115.Text = "Ц";
            this.button115.UseVisualStyleBackColor = false;
            this.button115.Visible = false;
            // 
            // button116
            // 
            this.button116.BackColor = System.Drawing.SystemColors.Control;
            this.button116.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button116.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button116.Location = new System.Drawing.Point(158, 328);
            this.button116.Name = "button116";
            this.button116.Size = new System.Drawing.Size(31, 31);
            this.button116.TabIndex = 157;
            this.button116.Text = "Х";
            this.button116.UseVisualStyleBackColor = false;
            this.button116.Visible = false;
            // 
            // button117
            // 
            this.button117.BackColor = System.Drawing.SystemColors.Control;
            this.button117.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button117.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button117.Location = new System.Drawing.Point(121, 328);
            this.button117.Name = "button117";
            this.button117.Size = new System.Drawing.Size(31, 31);
            this.button117.TabIndex = 156;
            this.button117.Text = "Ф";
            this.button117.UseVisualStyleBackColor = false;
            this.button117.Visible = false;
            // 
            // button118
            // 
            this.button118.BackColor = System.Drawing.SystemColors.Control;
            this.button118.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button118.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button118.Location = new System.Drawing.Point(83, 328);
            this.button118.Name = "button118";
            this.button118.Size = new System.Drawing.Size(31, 31);
            this.button118.TabIndex = 155;
            this.button118.Text = "У";
            this.button118.UseVisualStyleBackColor = false;
            this.button118.Visible = false;
            // 
            // button119
            // 
            this.button119.BackColor = System.Drawing.SystemColors.Control;
            this.button119.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button119.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button119.Location = new System.Drawing.Point(46, 328);
            this.button119.Name = "button119";
            this.button119.Size = new System.Drawing.Size(31, 31);
            this.button119.TabIndex = 154;
            this.button119.Text = "Т";
            this.button119.UseVisualStyleBackColor = false;
            this.button119.Visible = false;
            // 
            // button120
            // 
            this.button120.BackColor = System.Drawing.SystemColors.Control;
            this.button120.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button120.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button120.Location = new System.Drawing.Point(9, 328);
            this.button120.Name = "button120";
            this.button120.Size = new System.Drawing.Size(31, 31);
            this.button120.TabIndex = 153;
            this.button120.Text = "С";
            this.button120.UseVisualStyleBackColor = false;
            this.button120.Visible = false;
            // 
            // button121
            // 
            this.button121.BackColor = System.Drawing.SystemColors.Control;
            this.button121.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button121.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button121.Location = new System.Drawing.Point(195, 291);
            this.button121.Name = "button121";
            this.button121.Size = new System.Drawing.Size(31, 31);
            this.button121.TabIndex = 152;
            this.button121.Text = "Н";
            this.button121.UseVisualStyleBackColor = false;
            this.button121.Visible = false;
            // 
            // button122
            // 
            this.button122.BackColor = System.Drawing.SystemColors.Control;
            this.button122.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button122.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button122.Location = new System.Drawing.Point(158, 291);
            this.button122.Name = "button122";
            this.button122.Size = new System.Drawing.Size(31, 31);
            this.button122.TabIndex = 151;
            this.button122.Text = "М";
            this.button122.UseVisualStyleBackColor = false;
            this.button122.Visible = false;
            // 
            // button123
            // 
            this.button123.BackColor = System.Drawing.SystemColors.Control;
            this.button123.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button123.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button123.Location = new System.Drawing.Point(121, 291);
            this.button123.Name = "button123";
            this.button123.Size = new System.Drawing.Size(31, 31);
            this.button123.TabIndex = 150;
            this.button123.Text = "Л";
            this.button123.UseVisualStyleBackColor = false;
            this.button123.Visible = false;
            // 
            // button124
            // 
            this.button124.BackColor = System.Drawing.SystemColors.Control;
            this.button124.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button124.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button124.Location = new System.Drawing.Point(83, 291);
            this.button124.Name = "button124";
            this.button124.Size = new System.Drawing.Size(31, 31);
            this.button124.TabIndex = 149;
            this.button124.Text = "К";
            this.button124.UseVisualStyleBackColor = false;
            this.button124.Visible = false;
            // 
            // button125
            // 
            this.button125.BackColor = System.Drawing.SystemColors.Control;
            this.button125.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button125.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button125.Location = new System.Drawing.Point(46, 291);
            this.button125.Name = "button125";
            this.button125.Size = new System.Drawing.Size(31, 31);
            this.button125.TabIndex = 148;
            this.button125.Text = "Й";
            this.button125.UseVisualStyleBackColor = false;
            this.button125.Visible = false;
            // 
            // button126
            // 
            this.button126.BackColor = System.Drawing.SystemColors.Control;
            this.button126.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button126.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button126.Location = new System.Drawing.Point(9, 291);
            this.button126.Name = "button126";
            this.button126.Size = new System.Drawing.Size(31, 31);
            this.button126.TabIndex = 147;
            this.button126.Text = "И";
            this.button126.UseVisualStyleBackColor = false;
            this.button126.Visible = false;
            // 
            // button127
            // 
            this.button127.BackColor = System.Drawing.SystemColors.Control;
            this.button127.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button127.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button127.Location = new System.Drawing.Point(195, 254);
            this.button127.Name = "button127";
            this.button127.Size = new System.Drawing.Size(31, 31);
            this.button127.TabIndex = 146;
            this.button127.Text = "Е";
            this.button127.UseVisualStyleBackColor = false;
            this.button127.Visible = false;
            // 
            // button128
            // 
            this.button128.BackColor = System.Drawing.SystemColors.Control;
            this.button128.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button128.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button128.Location = new System.Drawing.Point(158, 254);
            this.button128.Name = "button128";
            this.button128.Size = new System.Drawing.Size(31, 31);
            this.button128.TabIndex = 145;
            this.button128.Text = "Д";
            this.button128.UseVisualStyleBackColor = false;
            this.button128.Visible = false;
            // 
            // button129
            // 
            this.button129.BackColor = System.Drawing.SystemColors.Control;
            this.button129.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button129.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button129.Location = new System.Drawing.Point(121, 254);
            this.button129.Name = "button129";
            this.button129.Size = new System.Drawing.Size(31, 31);
            this.button129.TabIndex = 144;
            this.button129.Text = "Г";
            this.button129.UseVisualStyleBackColor = false;
            this.button129.Visible = false;
            // 
            // button130
            // 
            this.button130.BackColor = System.Drawing.SystemColors.Control;
            this.button130.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button130.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button130.Location = new System.Drawing.Point(84, 254);
            this.button130.Name = "button130";
            this.button130.Size = new System.Drawing.Size(31, 31);
            this.button130.TabIndex = 143;
            this.button130.Text = "В";
            this.button130.UseVisualStyleBackColor = false;
            this.button130.Visible = false;
            // 
            // button131
            // 
            this.button131.BackColor = System.Drawing.SystemColors.Control;
            this.button131.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button131.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button131.Location = new System.Drawing.Point(46, 254);
            this.button131.Name = "button131";
            this.button131.Size = new System.Drawing.Size(31, 31);
            this.button131.TabIndex = 142;
            this.button131.Text = "Б";
            this.button131.UseVisualStyleBackColor = false;
            this.button131.Visible = false;
            // 
            // button132
            // 
            this.button132.BackColor = System.Drawing.SystemColors.Control;
            this.button132.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button132.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.button132.Location = new System.Drawing.Point(9, 254);
            this.button132.Name = "button132";
            this.button132.Size = new System.Drawing.Size(31, 31);
            this.button132.TabIndex = 141;
            this.button132.Text = "А";
            this.button132.UseVisualStyleBackColor = false;
            this.button132.Visible = false;
            // 
            // label9
            // 
            this.label9.BackColor = System.Drawing.Color.White;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Block;
            this.label9.Location = new System.Drawing.Point(18, 176);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(35, 39);
            this.label9.TabIndex = 207;
            this.label9.Text = "Б";
            this.label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label9.Visible = false;
            // 
            // label10
            // 
            this.label10.BackColor = System.Drawing.Color.White;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Block;
            this.label10.Location = new System.Drawing.Point(74, 176);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(35, 39);
            this.label10.TabIndex = 208;
            this.label10.Text = "Е";
            this.label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label10.Visible = false;
            // 
            // label11
            // 
            this.label11.BackColor = System.Drawing.Color.White;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Block;
            this.label11.Location = new System.Drawing.Point(130, 176);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(35, 39);
            this.label11.TabIndex = 209;
            this.label11.Text = "Р";
            this.label11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label11.Visible = false;
            // 
            // label12
            // 
            this.label12.BackColor = System.Drawing.Color.White;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Block;
            this.label12.Location = new System.Drawing.Point(186, 176);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(35, 39);
            this.label12.TabIndex = 210;
            this.label12.Text = "Ё";
            this.label12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label12.Visible = false;
            // 
            // label13
            // 
            this.label13.BackColor = System.Drawing.Color.White;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Block;
            this.label13.Location = new System.Drawing.Point(242, 176);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(35, 39);
            this.label13.TabIndex = 211;
            this.label13.Text = "З";
            this.label13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label13.Visible = false;
            // 
            // label14
            // 
            this.label14.BackColor = System.Drawing.Color.White;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 27.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Block;
            this.label14.Location = new System.Drawing.Point(299, 176);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(35, 39);
            this.label14.TabIndex = 212;
            this.label14.Text = "А";
            this.label14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label14.Visible = false;
            // 
            // timer21
            // 
            this.timer21.Interval = 3500;
            this.timer21.Tick += new System.EventHandler(this.timer21_Tick);
            // 
            // timer22
            // 
            this.timer22.Interval = 4500;
            this.timer22.Tick += new System.EventHandler(this.timer22_Tick);
            // 
            // timer23
            // 
            this.timer23.Interval = 5500;
            this.timer23.Tick += new System.EventHandler(this.timer23_Tick);
            // 
            // label15
            // 
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.label15.Location = new System.Drawing.Point(227, 29);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(61, 23);
            this.label15.TabIndex = 213;
            this.label15.Text = "0";
            this.label15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label15.Visible = false;
            // 
            // label16
            // 
            this.label16.Enabled = false;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.label16.Location = new System.Drawing.Point(227, 55);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(61, 23);
            this.label16.TabIndex = 214;
            this.label16.Text = "1";
            this.label16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label16.Visible = false;
            // 
            // label17
            // 
            this.label17.Enabled = false;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.label17.Location = new System.Drawing.Point(227, 84);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(61, 23);
            this.label17.TabIndex = 215;
            this.label17.Text = "1";
            this.label17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label17.Visible = false;
            // 
            // label18
            // 
            this.label18.Enabled = false;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.label18.Location = new System.Drawing.Point(227, 110);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(61, 23);
            this.label18.TabIndex = 216;
            this.label18.Text = "1";
            this.label18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label18.Visible = false;
            // 
            // label19
            // 
            this.label19.Enabled = false;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.label19.Location = new System.Drawing.Point(227, 137);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(61, 23);
            this.label19.TabIndex = 217;
            this.label19.Text = "1";
            this.label19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label19.Visible = false;
            // 
            // label20
            // 
            this.label20.Enabled = false;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.label20.Location = new System.Drawing.Point(227, 167);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(61, 23);
            this.label20.TabIndex = 218;
            this.label20.Text = "1";
            this.label20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label20.Visible = false;
            // 
            // label21
            // 
            this.label21.Enabled = false;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Image = global::Pole_Chudes_Beta_1.Properties.Resources.Back1;
            this.label21.Location = new System.Drawing.Point(227, 193);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(61, 23);
            this.label21.TabIndex = 219;
            this.label21.Text = "1";
            this.label21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.label21.Visible = false;
            // 
            // timer24
            // 
            this.timer24.Interval = 5500;
            this.timer24.Tick += new System.EventHandler(this.timer24_Tick);
            // 
            // btnSrazyRast
            // 
            this.btnSrazyRast.BackColor = System.Drawing.SystemColors.Control;
            this.btnSrazyRast.Enabled = false;
            this.btnSrazyRast.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSrazyRast.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnSrazyRast.Location = new System.Drawing.Point(174, 407);
            this.btnSrazyRast.Name = "btnSrazyRast";
            this.btnSrazyRast.Size = new System.Drawing.Size(173, 26);
            this.btnSrazyRast.TabIndex = 220;
            this.btnSrazyRast.Text = "Ввести слово сразу";
            this.btnSrazyRast.UseVisualStyleBackColor = false;
            this.btnSrazyRast.Visible = false;
            this.btnSrazyRast.Click += new System.EventHandler(this.btnSrazyRast_Click);
            // 
            // btnRastOk
            // 
            this.btnRastOk.BackColor = System.Drawing.SystemColors.Control;
            this.btnRastOk.Enabled = false;
            this.btnRastOk.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRastOk.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnRastOk.Location = new System.Drawing.Point(188, 407);
            this.btnRastOk.Name = "btnRastOk";
            this.btnRastOk.Size = new System.Drawing.Size(40, 24);
            this.btnRastOk.TabIndex = 221;
            this.btnRastOk.Text = "ОК";
            this.btnRastOk.UseVisualStyleBackColor = false;
            this.btnRastOk.Visible = false;
            this.btnRastOk.Click += new System.EventHandler(this.btnRastOk_Click);
            // 
            // tbSrazyRast
            // 
            this.tbSrazyRast.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.tbSrazyRast.Enabled = false;
            this.tbSrazyRast.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.tbSrazyRast.Location = new System.Drawing.Point(41, 407);
            this.tbSrazyRast.Name = "tbSrazyRast";
            this.tbSrazyRast.Size = new System.Drawing.Size(141, 24);
            this.tbSrazyRast.TabIndex = 222;
            this.tbSrazyRast.Visible = false;
            // 
            // btnRastClose
            // 
            this.btnRastClose.BackColor = System.Drawing.SystemColors.Control;
            this.btnRastClose.Enabled = false;
            this.btnRastClose.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnRastClose.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.btnRastClose.Location = new System.Drawing.Point(9, 407);
            this.btnRastClose.Name = "btnRastClose";
            this.btnRastClose.Size = new System.Drawing.Size(26, 24);
            this.btnRastClose.TabIndex = 223;
            this.btnRastClose.Text = "X";
            this.btnRastClose.UseVisualStyleBackColor = false;
            this.btnRastClose.Visible = false;
            this.btnRastClose.Click += new System.EventHandler(this.btnRastClose_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.ClientSize = new System.Drawing.Size(640, 441);
            this.Controls.Add(this.btnRastClose);
            this.Controls.Add(this.tbSrazyRast);
            this.Controls.Add(this.btnRastOk);
            this.Controls.Add(this.btnSrazyRast);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.button67);
            this.Controls.Add(this.button68);
            this.Controls.Add(this.button69);
            this.Controls.Add(this.button70);
            this.Controls.Add(this.button71);
            this.Controls.Add(this.button72);
            this.Controls.Add(this.button73);
            this.Controls.Add(this.button74);
            this.Controls.Add(this.button75);
            this.Controls.Add(this.button76);
            this.Controls.Add(this.button77);
            this.Controls.Add(this.button78);
            this.Controls.Add(this.button79);
            this.Controls.Add(this.button80);
            this.Controls.Add(this.button81);
            this.Controls.Add(this.button82);
            this.Controls.Add(this.button83);
            this.Controls.Add(this.button84);
            this.Controls.Add(this.button85);
            this.Controls.Add(this.button86);
            this.Controls.Add(this.button87);
            this.Controls.Add(this.button88);
            this.Controls.Add(this.button89);
            this.Controls.Add(this.button90);
            this.Controls.Add(this.button91);
            this.Controls.Add(this.button92);
            this.Controls.Add(this.button93);
            this.Controls.Add(this.button94);
            this.Controls.Add(this.button95);
            this.Controls.Add(this.button96);
            this.Controls.Add(this.button97);
            this.Controls.Add(this.button98);
            this.Controls.Add(this.button99);
            this.Controls.Add(this.button100);
            this.Controls.Add(this.button101);
            this.Controls.Add(this.button102);
            this.Controls.Add(this.button103);
            this.Controls.Add(this.button104);
            this.Controls.Add(this.button105);
            this.Controls.Add(this.button106);
            this.Controls.Add(this.button107);
            this.Controls.Add(this.button108);
            this.Controls.Add(this.button109);
            this.Controls.Add(this.button110);
            this.Controls.Add(this.button111);
            this.Controls.Add(this.button112);
            this.Controls.Add(this.button113);
            this.Controls.Add(this.button114);
            this.Controls.Add(this.button115);
            this.Controls.Add(this.button116);
            this.Controls.Add(this.button117);
            this.Controls.Add(this.button118);
            this.Controls.Add(this.button119);
            this.Controls.Add(this.button120);
            this.Controls.Add(this.button121);
            this.Controls.Add(this.button122);
            this.Controls.Add(this.button123);
            this.Controls.Add(this.button124);
            this.Controls.Add(this.button125);
            this.Controls.Add(this.button126);
            this.Controls.Add(this.button127);
            this.Controls.Add(this.button128);
            this.Controls.Add(this.button129);
            this.Controls.Add(this.button130);
            this.Controls.Add(this.button131);
            this.Controls.Add(this.button132);
            this.Controls.Add(this.btnBaraban3);
            this.Controls.Add(this.lblTextRast1);
            this.Controls.Add(this.btnPocClose);
            this.Controls.Add(this.tbSrazyPoc);
            this.Controls.Add(this.btnPocOk);
            this.Controls.Add(this.btnSrazyPoc);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblV);
            this.Controls.Add(this.lblE);
            this.Controls.Add(this.lblSH);
            this.Controls.Add(this.lblY);
            this.Controls.Add(this.lblN);
            this.Controls.Add(this.lblO);
            this.Controls.Add(this.lblK);
            this.Controls.Add(this.button34);
            this.Controls.Add(this.button35);
            this.Controls.Add(this.button36);
            this.Controls.Add(this.button37);
            this.Controls.Add(this.button38);
            this.Controls.Add(this.button39);
            this.Controls.Add(this.button40);
            this.Controls.Add(this.button41);
            this.Controls.Add(this.button42);
            this.Controls.Add(this.button43);
            this.Controls.Add(this.button44);
            this.Controls.Add(this.button45);
            this.Controls.Add(this.button46);
            this.Controls.Add(this.button47);
            this.Controls.Add(this.button48);
            this.Controls.Add(this.button49);
            this.Controls.Add(this.button50);
            this.Controls.Add(this.button51);
            this.Controls.Add(this.button52);
            this.Controls.Add(this.button53);
            this.Controls.Add(this.button54);
            this.Controls.Add(this.button55);
            this.Controls.Add(this.button56);
            this.Controls.Add(this.button57);
            this.Controls.Add(this.button58);
            this.Controls.Add(this.button59);
            this.Controls.Add(this.button60);
            this.Controls.Add(this.button61);
            this.Controls.Add(this.button62);
            this.Controls.Add(this.button63);
            this.Controls.Add(this.button64);
            this.Controls.Add(this.button65);
            this.Controls.Add(this.button66);
            this.Controls.Add(this.btnBaraban2);
            this.Controls.Add(this.lblTextPoc1);
            this.Controls.Add(this.btnProgOk);
            this.Controls.Add(this.btnProgClose);
            this.Controls.Add(this.tbSrazyProg);
            this.Controls.Add(this.btnSrazyProg);
            this.Controls.Add(this.lblSix);
            this.Controls.Add(this.lblFive);
            this.Controls.Add(this.lblFour);
            this.Controls.Add(this.lblThree);
            this.Controls.Add(this.lblTwo);
            this.Controls.Add(this.lblOne);
            this.Controls.Add(this.lblSlovoCount);
            this.Controls.Add(this.lblTextProg4);
            this.Controls.Add(this.lblTextProg3);
            this.Controls.Add(this.lblTextProg2);
            this.Controls.Add(this.lblC);
            this.Controls.Add(this.lblii);
            this.Controls.Add(this.lblS);
            this.Controls.Add(this.lblI);
            this.Controls.Add(this.lblA);
            this.Controls.Add(this.lblB);
            this.Controls.Add(this.button33);
            this.Controls.Add(this.button32);
            this.Controls.Add(this.button31);
            this.Controls.Add(this.button30);
            this.Controls.Add(this.button29);
            this.Controls.Add(this.button28);
            this.Controls.Add(this.button27);
            this.Controls.Add(this.button26);
            this.Controls.Add(this.button25);
            this.Controls.Add(this.button24);
            this.Controls.Add(this.button23);
            this.Controls.Add(this.button22);
            this.Controls.Add(this.button21);
            this.Controls.Add(this.button20);
            this.Controls.Add(this.button19);
            this.Controls.Add(this.button18);
            this.Controls.Add(this.button17);
            this.Controls.Add(this.button16);
            this.Controls.Add(this.button15);
            this.Controls.Add(this.button14);
            this.Controls.Add(this.button13);
            this.Controls.Add(this.button12);
            this.Controls.Add(this.button11);
            this.Controls.Add(this.button10);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.button6);
            this.Controls.Add(this.button5);
            this.Controls.Add(this.button4);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.lblItak);
            this.Controls.Add(this.lblBukva);
            this.Controls.Add(this.lblOchki);
            this.Controls.Add(this.lblVyvodBar);
            this.Controls.Add(this.lblNaBarabane);
            this.Controls.Add(this.lblBarabanResult);
            this.Controls.Add(this.btnBaraban);
            this.Controls.Add(this.lblCount);
            this.Controls.Add(this.lblTextProg1);
            this.Controls.Add(this.List);
            this.Controls.Add(this.lblPlayerName1);
            this.Controls.Add(this.lblErr);
            this.Controls.Add(this.tbPName);
            this.Controls.Add(this.lblEnterName);
            this.Controls.Add(this.btnRast);
            this.Controls.Add(this.btnPoc);
            this.Controls.Add(this.btnProg);
            this.Controls.Add(this.lblVybor);
            this.Controls.Add(this.btnNewGame);
            this.Controls.Add(this.menuStrip1);
            this.Controls.Add(this.ThemeBack);
            this.Controls.Add(this.pbPlayerStatus);
            this.Controls.Add(this.pbGProg1);
            this.Controls.Add(this.pbGProg2);
            this.Controls.Add(this.pbGProg3);
            this.Controls.Add(this.pbGProg4);
            this.Controls.Add(this.pbGProg5);
            this.Controls.Add(this.pbGProg6);
            this.Controls.Add(this.pbGProg7);
            this.Controls.Add(this.MenuBack);
            this.Controls.Add(this.GameBack);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.menuStrip1;
            this.MaximizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Pole Chudes Beta 1";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.List)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGProg6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGProg5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGProg4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGProg3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGProg2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGProg1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ThemeBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbPlayerStatus)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.MenuBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GameBack)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbGProg7)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox MenuBack;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.Button btnNewGame;
        private System.Windows.Forms.ToolStripMenuItem играToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem оПрограммеToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выйтиToolStripMenuItem;
        private System.Windows.Forms.PictureBox GameBack;
        private System.Windows.Forms.PictureBox ThemeBack;
        private System.Windows.Forms.Label lblVybor;
        private System.Windows.Forms.Button btnProg;
        private System.Windows.Forms.Button btnPoc;
        private System.Windows.Forms.Button btnRast;
        private System.Windows.Forms.TextBox tbPName;
        private System.Windows.Forms.Label lblEnterName;
        private System.Windows.Forms.Label lblErr;
        private System.Windows.Forms.PictureBox pbPlayerStatus;
        private System.Windows.Forms.Label lblPlayerName1;
        private System.Windows.Forms.PictureBox pbGProg1;
        private System.Windows.Forms.PictureBox pbGProg2;
        private System.Windows.Forms.PictureBox pbGProg3;
        private System.Windows.Forms.PictureBox pbGProg4;
        private System.Windows.Forms.PictureBox pbGProg5;
        private System.Windows.Forms.PictureBox pbGProg6;
        private System.Windows.Forms.PictureBox List;
        private System.Windows.Forms.Label lblTextProg1;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.Label lblCount;
        private System.Windows.Forms.Button btnBaraban;
        private System.Windows.Forms.Label lblBarabanResult;
        private System.Windows.Forms.Label lblNaBarabane;
        private System.Windows.Forms.Label lblItak;
        private System.Windows.Forms.Label lblVyvodBar;
        private System.Windows.Forms.Timer timer3;
        private System.Windows.Forms.Label lblOchki;
        private System.Windows.Forms.Label lblBukva;
        private System.Windows.Forms.Timer timer4;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button4;
        private System.Windows.Forms.Button button5;
        private System.Windows.Forms.Button button6;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
        private System.Windows.Forms.Button button10;
        private System.Windows.Forms.Button button11;
        private System.Windows.Forms.Button button12;
        private System.Windows.Forms.Button button13;
        private System.Windows.Forms.Button button14;
        private System.Windows.Forms.Button button15;
        private System.Windows.Forms.Button button16;
        private System.Windows.Forms.Button button17;
        private System.Windows.Forms.Button button18;
        private System.Windows.Forms.Button button19;
        private System.Windows.Forms.Button button20;
        private System.Windows.Forms.Button button21;
        private System.Windows.Forms.Button button22;
        private System.Windows.Forms.Button button23;
        private System.Windows.Forms.Button button24;
        private System.Windows.Forms.Button button25;
        private System.Windows.Forms.Button button26;
        private System.Windows.Forms.Button button27;
        private System.Windows.Forms.Button button28;
        private System.Windows.Forms.Button button29;
        private System.Windows.Forms.Button button30;
        private System.Windows.Forms.Button button31;
        private System.Windows.Forms.Button button32;
        private System.Windows.Forms.Button button33;
        private System.Windows.Forms.Label lblB;
        private System.Windows.Forms.Label lblA;
        private System.Windows.Forms.Label lblI;
        private System.Windows.Forms.Label lblS;
        private System.Windows.Forms.Label lblii;
        private System.Windows.Forms.Label lblC;
        private System.Windows.Forms.Timer timer5;
        private System.Windows.Forms.Label lblTextProg2;
        private System.Windows.Forms.Timer timer6;
        private System.Windows.Forms.Label lblTextProg3;
        private System.Windows.Forms.Label lblTextProg4;
        private System.Windows.Forms.Timer timer7;
        private System.Windows.Forms.Label lblSlovoCount;
        private System.Windows.Forms.Label lblOne;
        private System.Windows.Forms.Label lblTwo;
        private System.Windows.Forms.Label lblThree;
        private System.Windows.Forms.Label lblFour;
        private System.Windows.Forms.Label lblFive;
        private System.Windows.Forms.Label lblSix;
        private System.Windows.Forms.Timer timer8;
        private System.Windows.Forms.Button btnSrazyProg;
        private System.Windows.Forms.TextBox tbSrazyProg;
        private System.Windows.Forms.Button btnProgClose;
        private System.Windows.Forms.Button btnProgOk;
        private System.Windows.Forms.PictureBox pbGProg7;
        private System.Windows.Forms.Timer timer9;
        private System.Windows.Forms.Label lblTextPoc1;
        private System.Windows.Forms.Timer timer10;
        private System.Windows.Forms.Button btnBaraban2;
        private System.Windows.Forms.Button button34;
        private System.Windows.Forms.Button button35;
        private System.Windows.Forms.Button button36;
        private System.Windows.Forms.Button button37;
        private System.Windows.Forms.Button button38;
        private System.Windows.Forms.Button button39;
        private System.Windows.Forms.Button button40;
        private System.Windows.Forms.Button button41;
        private System.Windows.Forms.Button button42;
        private System.Windows.Forms.Button button43;
        private System.Windows.Forms.Button button44;
        private System.Windows.Forms.Button button45;
        private System.Windows.Forms.Button button46;
        private System.Windows.Forms.Button button47;
        private System.Windows.Forms.Button button48;
        private System.Windows.Forms.Button button49;
        private System.Windows.Forms.Button button50;
        private System.Windows.Forms.Button button51;
        private System.Windows.Forms.Button button52;
        private System.Windows.Forms.Button button53;
        private System.Windows.Forms.Button button54;
        private System.Windows.Forms.Button button55;
        private System.Windows.Forms.Button button56;
        private System.Windows.Forms.Button button57;
        private System.Windows.Forms.Button button58;
        private System.Windows.Forms.Button button59;
        private System.Windows.Forms.Button button60;
        private System.Windows.Forms.Button button61;
        private System.Windows.Forms.Button button62;
        private System.Windows.Forms.Button button63;
        private System.Windows.Forms.Button button64;
        private System.Windows.Forms.Button button65;
        private System.Windows.Forms.Button button66;
        private System.Windows.Forms.Timer timer11;
        private System.Windows.Forms.Timer timer12;
        private System.Windows.Forms.Label lblK;
        private System.Windows.Forms.Label lblO;
        private System.Windows.Forms.Label lblN;
        private System.Windows.Forms.Label lblY;
        private System.Windows.Forms.Label lblSH;
        private System.Windows.Forms.Label lblE;
        private System.Windows.Forms.Label lblV;
        private System.Windows.Forms.Timer timer13;
        private System.Windows.Forms.Timer timer14;
        private System.Windows.Forms.Timer timer15;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Timer timer16;
        private System.Windows.Forms.Button btnSrazyPoc;
        private System.Windows.Forms.Button btnPocOk;
        private System.Windows.Forms.TextBox tbSrazyPoc;
        private System.Windows.Forms.Button btnPocClose;
        private System.Windows.Forms.Timer timer17;
        private System.Windows.Forms.Label lblTextRast1;
        private System.Windows.Forms.Timer timer18;
        private System.Windows.Forms.Button btnBaraban3;
        private System.Windows.Forms.Timer timer19;
        private System.Windows.Forms.Timer timer20;
        private System.Windows.Forms.Button button67;
        private System.Windows.Forms.Button button68;
        private System.Windows.Forms.Button button69;
        private System.Windows.Forms.Button button70;
        private System.Windows.Forms.Button button71;
        private System.Windows.Forms.Button button72;
        private System.Windows.Forms.Button button73;
        private System.Windows.Forms.Button button74;
        private System.Windows.Forms.Button button75;
        private System.Windows.Forms.Button button76;
        private System.Windows.Forms.Button button77;
        private System.Windows.Forms.Button button78;
        private System.Windows.Forms.Button button79;
        private System.Windows.Forms.Button button80;
        private System.Windows.Forms.Button button81;
        private System.Windows.Forms.Button button82;
        private System.Windows.Forms.Button button83;
        private System.Windows.Forms.Button button84;
        private System.Windows.Forms.Button button85;
        private System.Windows.Forms.Button button86;
        private System.Windows.Forms.Button button87;
        private System.Windows.Forms.Button button88;
        private System.Windows.Forms.Button button89;
        private System.Windows.Forms.Button button90;
        private System.Windows.Forms.Button button91;
        private System.Windows.Forms.Button button92;
        private System.Windows.Forms.Button button93;
        private System.Windows.Forms.Button button94;
        private System.Windows.Forms.Button button95;
        private System.Windows.Forms.Button button96;
        private System.Windows.Forms.Button button97;
        private System.Windows.Forms.Button button98;
        private System.Windows.Forms.Button button99;
        private System.Windows.Forms.Button button100;
        private System.Windows.Forms.Button button101;
        private System.Windows.Forms.Button button102;
        private System.Windows.Forms.Button button103;
        private System.Windows.Forms.Button button104;
        private System.Windows.Forms.Button button105;
        private System.Windows.Forms.Button button106;
        private System.Windows.Forms.Button button107;
        private System.Windows.Forms.Button button108;
        private System.Windows.Forms.Button button109;
        private System.Windows.Forms.Button button110;
        private System.Windows.Forms.Button button111;
        private System.Windows.Forms.Button button112;
        private System.Windows.Forms.Button button113;
        private System.Windows.Forms.Button button114;
        private System.Windows.Forms.Button button115;
        private System.Windows.Forms.Button button116;
        private System.Windows.Forms.Button button117;
        private System.Windows.Forms.Button button118;
        private System.Windows.Forms.Button button119;
        private System.Windows.Forms.Button button120;
        private System.Windows.Forms.Button button121;
        private System.Windows.Forms.Button button122;
        private System.Windows.Forms.Button button123;
        private System.Windows.Forms.Button button124;
        private System.Windows.Forms.Button button125;
        private System.Windows.Forms.Button button126;
        private System.Windows.Forms.Button button127;
        private System.Windows.Forms.Button button128;
        private System.Windows.Forms.Button button129;
        private System.Windows.Forms.Button button130;
        private System.Windows.Forms.Button button131;
        private System.Windows.Forms.Button button132;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Timer timer21;
        private System.Windows.Forms.Timer timer22;
        private System.Windows.Forms.Timer timer23;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Timer timer24;
        private System.Windows.Forms.Button btnSrazyRast;
        private System.Windows.Forms.Button btnRastOk;
        private System.Windows.Forms.TextBox tbSrazyRast;
        private System.Windows.Forms.Button btnRastClose;
        private System.Windows.Forms.ToolStripMenuItem выбратьДругуюТемуToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem выбратьДругуюТемуToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem выбратьДругуюТемуToolStripMenuItem2;
    }
}

